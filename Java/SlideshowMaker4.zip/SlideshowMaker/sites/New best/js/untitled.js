var i = 0, imgsrc = new Array(), preload = new Array();
imgsrc[0]="img/BryceCanyonUtah.jpg";
imgsrc[1]="img/CapeSpearNewfoundland.jpg";
imgsrc[2]="img/SignalHillNewfoundland.jpg";
imgsrc[3]="img/YosemiteCalifornia.jpg";
imgsrc[4]="img/CarhengeNebraska.jpg";
imgsrc[5]="img/GrosMorneNewfoundland.jpg";
var person = ["Slide4","Slide1","Slide2","Slide3","sdkvasdjc","sdvsadvvd"];

function startSlideshow()
{
if(smode=="play")
{	

    document.getElementById("play").value="Pause";
    //document.getElementById("pause").disabled="";
    //document.getElementById("stop").disabled="";
    document.getElementById("slideshow").src=imgsrc[i];
    document.getElementById("demo").innerHTML = person[i];
			i++;
			setTimeout("startSlideshow()",3000);
	
}
else if(smode=="next")
	
{   

	
	if(i<(imgsrc.length-1))
	{
		i++;
   		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
    }
	else
	{
		i=0;
		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
	}
	
	
	
	
}
else if(smode=="previous")
{
	
	
	if(i>0)
	{
		i--;
   		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
    }
	else
	{
		i=imgsrc.length-1;
		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
	}


   
}
if(i==imgsrc.length)
{
i=0;
}
}