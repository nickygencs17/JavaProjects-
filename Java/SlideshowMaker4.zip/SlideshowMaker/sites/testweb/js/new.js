var i = 0, imgsrc = new Array(), preload = new Array();
imgsrc[0]="img/GreatPlainsNebraska.jpg";
imgsrc[1]="img/BryceCanyonUtah.jpg";
imgsrc[2]="img/BadlandsSouthDakota.jpg";
var person = ["hi","nick","l"];


for (var j=0;j<imgsrc.length;j++)
{
preload[j] = new Image;
preload[j].src = imgsrc[j];
}
function mode(param)
{
smode=param;
}


function startSlideshow()
{
if(smode=="play")
{
document.getElementById("play").hidden="hidden";
document.getElementById("pause").hidden="";
document.getElementById("slideshow").src=imgsrc[i];
document.getElementById("demo").innerHTML = person[i];
i++;
setTimeout("startSlideshow()",3000);
}
else if(smode=="pause")
{
document.getElementById("pause").hidden="hidden";
document.getElementById("play").hidden="";
document.getElementById("play").value="Resume";
}
else if(smode=="stop")
{
document.getElementById("play").disabled="";
document.getElementById("play").value="Play";
document.getElementById("pause").disabled="disabled";
document.getElementById("slideshow").src=imgsrc[i];
document.getElementById("demo").innerHTML = person[i];
i=0;
}
else if(smode=="next")
	
{   

	
	if(i<(imgsrc.length-1))
	{
		i++;
   		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
    }
	else
	{
		i=0;
		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
	}
	
	
	
	
}
else if(smode=="previous")
{
	
	
	if(i>0)
	{
		i--;
   		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
    }
	else
	{
		i=imgsrc.length-1;
		document.getElementById("slideshow").src=imgsrc[i];
		document.getElementById("demo").innerHTML = person[i];
	}


   
}
if(i==imgsrc.length)
{
i=0;
}
}
