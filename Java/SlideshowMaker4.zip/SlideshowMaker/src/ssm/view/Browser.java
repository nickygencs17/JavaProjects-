package ssm.view;

import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javafx.collections.ObservableList;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.scene.layout.Region;
import javax.imageio.ImageIO;

import ssm.model.Slide;

public class Browser extends Region {

    final WebView browser = new WebView();
    final WebEngine webEngine = browser.getEngine();

    public Browser(ObservableList<Slide> slides, String title) throws IOException {
        String os = System.getProperty("os.name");
        System.out.println(os);
        String slash = "\\";
        String divSlides = "";
        String divCaptions = "";
        String strManyDirectories = "sites/" + title + "/css";
        String strManyDirectories1 = "sites/" + title + "/js";
        String strManyDirectories3 = "sites/" + title + "/img";
        String strDirectoy = "test";
        String curDir = System.getProperty("user.dir");
        System.out.println(curDir);

        if (os.contains("Windows")) {

            String replaced = curDir.replace("\\", "/");
            curDir = replaced;

        }
        ///Users/nicholasgenco/Desktop/CSE HW 2/SlideshowMaker
        try {

            // Create multiple directories
            boolean success = (new File(strManyDirectories)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories + " created");
            }
            success = (new File(strManyDirectories1)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories1 + " created");
            }
            success = (new File(strManyDirectories3)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories3 + " created");
            }

        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
        String COPY_FILE_TO = strManyDirectories3;

        for (Slide s : slides) {

            String sfp = s.getImagePath();
            String sfn = s.getImageFileName();
            Path source = Paths.get(sfp + sfn); //original file 
            Path targetDir = Paths.get(strManyDirectories3 + "/" + sfn);
            Files.copy(source, targetDir, StandardCopyOption.REPLACE_EXISTING);

        }

        for (int i = 0; i < slides.size(); i++) {
            System.out.println("Nick" + i);
            Slide newSlide = slides.get(i);
            String path = "img/" + newSlide.getImageFileName();
            divSlides += "imgsrc[" + i + "]=\"" + path + "\";\n";

            if (i == slides.size() - 1) {
                divCaptions += "\"" + newSlide.getCaption() + "\"";
            } else {
                divCaptions += "\"" + newSlide.getCaption() + "\",";
            }
        }
        System.out.println(divSlides);
        FileWriter fWriterCSS = null;
        BufferedWriter writerCSS = null;

        try {
            //String filename = strManyDirectories2 + "/fileName.html";
            fWriterCSS = new FileWriter("sites/" + title + "/css/new.css");
            writerCSS = new BufferedWriter(fWriterCSS);
            writerCSS.write("<style>body {\n"
                    + "    background-color: #FFFF99;\n"
                    + "}\n"
                    + "body {\n"
                    + "    background-color: #FFFF99;\n"
                    + "}\n"
                    + "\n"
                    + "h1 {\n"
                    + "    font-family: \"Arial Black\", Gadget, sans-serif;\n"
                    + "	font-weight: bold;\n"
                    + "	font-size: 30px;\n"
                    + "}\n"
                    + "p {\n"
                    + "    font-family: \"Arial Black\", Gadget, sans-serif;\n"
                    + "	font-weight: bold;\n"
                    + "	font-size: 20px;\n"
                    + "}\n"
                    + "\n"
                    + "\n"
                    + "\n"
                    + "</style>");
            writerCSS.newLine(); //this is not actually needed for html files - can make your code more readable though 
            writerCSS.close(); //make sure you close the writer object 

        } catch (Exception e) {
            System.out.println("hellaascascasco");  //catch any exceptions here
        }
        FileWriter fWriterJS = null;
        BufferedWriter writerJS = null;

        try {
            //String filename = strManyDirectories2 + "/fileName.html";
            fWriterJS = new FileWriter("sites/" + title + "/js/new.js");
            writerJS = new BufferedWriter(fWriterJS);
            System.out.println("hello");
            writerJS.write("var i = 0, imgsrc = new Array(), preload = new Array();\n"
                    + divSlides + "var person = [" + divCaptions + "];\n"
                    + "\n"
                    + "\n"
                    + "for (var j=0;j<imgsrc.length;j++)\n"
                    + "{\n"
                    + "preload[j] = new Image;\n"
                    + "preload[j].src = imgsrc[j];\n"
                    + "}\n"
                    + "function mode(param)\n"
                    + "{\n"
                    + "smode=param;\n"
                    + "}\n"
                    + "\n"
                    + "\n"
                    + "function startSlideshow()\n"
                    + "{\n"
                    + "if(smode==\"play\")\n"
                    + "{\n"
                    + "document.getElementById(\"play\").hidden=\"hidden\";\n"
                    + "document.getElementById(\"pause\").hidden=\"\";\n"
                    + "document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "document.getElementById(\"demo\").innerHTML = person[i];\n" + "document.getElementById(\"previous\").hidden=\"hidden\";\n"
                    + "document.getElementById(\"next\").hidden=\"hidden\";"
                    + "i++;\n"
                    + "setTimeout(\"startSlideshow()\",3000);\n"
                    + "}\n"
                    + "else if(smode==\"pause\")\n"
                    + "{\n"
                    + "document.getElementById(\"pause\").hidden=\"hidden\";\n"
                    + "document.getElementById(\"play\").hidden=\"\";\n"
                    + "document.getElementById(\"play\").value=\"Resume\";\n" + "document.getElementById(\"previous\").hidden=\"\";\n"
                    + "document.getElementById(\"next\").hidden=\"\";"
                    + "}\n"
                    + "else if(smode==\"stop\")\n"
                    + "{\n"
                    + "document.getElementById(\"play\").disabled=\"\";\n"
                    + "document.getElementById(\"play\").value=\"Play\";\n"
                    + "document.getElementById(\"pause\").disabled=\"disabled\";\n"
                    + "document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "document.getElementById(\"demo\").innerHTML = person[i];\n"
                    + "i=0;\n"
                    + "}\n"
                    + "else if(smode==\"next\")\n"
                    + "	\n"
                    + "{   \n"
                    + "\n"
                    + "	\n"
                    + "	if(i<(imgsrc.length-1))\n"
                    + "	{\n"
                    + "		i++;\n"
                    + "   		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                    + "    }\n"
                    + "	else\n"
                    + "	{\n"
                    + "		i=0;\n"
                    + "		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                    + "	}\n"
                    + "	\n"
                    + "	\n"
                    + "	\n"
                    + "	\n"
                    + "}\n"
                    + "else if(smode==\"previous\")\n"
                    + "{\n"
                    + "	\n"
                    + "	\n"
                    + "	if(i>0)\n"
                    + "	{\n"
                    + "		i--;\n"
                    + "   		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                    + "    }\n"
                    + "	else\n"
                    + "	{\n"
                    + "		i=imgsrc.length-1;\n"
                    + "		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                    + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                    + "	}\n"
                    + "\n"
                    + "\n"
                    + "   \n"
                    + "}\n"
                    + "if(i==imgsrc.length)\n"
                    + "{\n"
                    + "i=0;\n"
                    + "}\n"
                    + "}");
            writerJS.newLine(); //this is not actually needed for html files - can make your code more readable though 
            writerJS.close(); //make sure you close the writer object 

        } catch (Exception e) {
            //catch any exceptions here
            System.out.println("hellaascascasco");
        }

        FileWriter fWriter = null;
        BufferedWriter writer = null;

        try {
            //String filename = strManyDirectories2 + "/fileName.html";
            fWriter = new FileWriter("sites/" + title + "/fileName.html");
            writer = new BufferedWriter(fWriter);
            writer.write("<!DOCTYPE html><html>\n"
                    + "<head>\n"
                    + "<title>" + title + "</title>\n"
                    + "<LINK rel=\"stylesheet\" type=\"text/css\" href=\"css/new.css\" title=\"Default Styles\" media=\"screen\"><script src=\"js/new.js\"></script></head>\n"
                    + "<body>\n"
                    + "<h1>" + title + "</h1><center><img id=\"slideshow\" src=\"../../lightning.png/\" height=\"400\" width=\"400\"/></center>\n"
                    + "<center><p id=\"demo\"></p></center>\n"
                    + "\n"
                    + "<br />\n"
                    + "<center>\n"
                    + "<input id=\"previous\" type=\"image\" src=\"../../images/icons/Previous.png\" width=\"20\" height=\"18\"  value=\"Previous\" onclick=\"mode('previous');startSlideshow();\"/>&nbsp;&nbsp;&nbsp;&nbsp;\n"
                    + "<input id=\"play\" type=\"image\" src=\"../../play.png\" width=\"20\" height=\"18\"  value=\"Play\" onclick=\"mode('play');startSlideshow();\" />\n"
                    + "<input id=\"pause\" type=\"image\" src=\"../../pause.png\" width=\"20\" height=\"18\" value=\"Pause\" hidden=\"hidden\" onclick=\"mode('pause');startSlideshow();\" />&nbsp;&nbsp;&nbsp;&nbsp;\n"
                    + "<input id=\"next\" type=\"image\" src=\"../../images/icons/Next.png\" width=\"20\" height=\"18\" value=\"Next\" onclick=\"mode('next');startSlideshow();\" />\n"
                    + "\n"
                    + "</center></body>");
            writer.newLine(); //this is not actually needed for html files - can make your code more readable though 
            writer.close(); //make sure you close the writer object 

        } catch (Exception e) {
            System.out.println("hellaascascasco");//catch any exceptions here
        }

        getStyleClass().add("browser");

        if (os.contains("Windows")) {
            browser.getEngine().load("file:///" + curDir + "/sites/" + title + "/fileName.html");
        } else {
            browser.getEngine().load("file://" + curDir + "/sites/" + title + "/fileName.html");

        }

        getChildren().add(browser);

    }
}
