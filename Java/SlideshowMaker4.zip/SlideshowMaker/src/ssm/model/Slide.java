package ssm.model;

import ssm.view.SlideEditView;

/**
 * This class represents a single slide in a slide show.
 *
 * @author McKilla Gorilla & _Genius Genco ____________
 */
public class Slide {

    String imageFileName;
    String imagePath;
    Boolean selected;
    private String caption;
    SlideEditView slideSlected;
   // String imageCaption;

    /**
     * Constructor, it initializes all slide data.
     *
     * @param initImageFileName File name of the image.
     *
     * @param initImagePath File path for the image.
     *
     */
    public Slide(String initImageFileName, String initImagePath, String initCaption) {
        imageFileName = initImageFileName;
        imagePath = initImagePath;
        caption = initCaption;
        selected = false;

        //selected = Selected;
        //imageCaption = initCaption;
    }

    // ACCESSOR METHODS
    public String getImageFileName() {
        return imageFileName;
    }

    public String getImagePath() {
        return imagePath;
    }

    public Boolean getSelected() {
        return selected;
    }

    public String getCaption() {
        return caption;
    }

    public SlideEditView getSLideEditView() {
        return slideSlected;
    }

    //public String getImageCaptions() {return imageCaption;}
    // MUTATOR METHODS
    public void setSelected(Boolean Selected) {
        selected = Selected;
    }

    public void setImageFileName(String initImageFileName) {
        imageFileName = initImageFileName;
    }

    public void setImagePath(String initImagePath) {
        imagePath = initImagePath;
    }

    public void setCaption(String initCaption) {
        caption = initCaption;

    }

    public void setImage(String initPath, String initFileName) {
        imagePath = initPath;
        imageFileName = initFileName;
        //caption = initCaption;
    }

}
