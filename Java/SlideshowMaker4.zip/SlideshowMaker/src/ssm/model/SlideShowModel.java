package ssm.model;

import java.util.ArrayList;
import javafx.scene.paint.Color;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import properties_manager.PropertiesManager;
import ssm.LanguagePropertyType;
import static ssm.StartupConstants.CSS_CLASS_SLIDE_SELECTED;
import ssm.error.ErrorHandler;
import ssm.view.SlideEditView;
import ssm.view.SlideShowMakerView;

/**
 * This class manages all the data associated with a slideshow.
 *
 * @author McKilla Gorilla & _Genius Genco ____________
 */
public class SlideShowModel {

    SlideShowMakerView ui;
    String title;
    ObservableList<Slide> slides;
    ArrayList<ImageView> imageviews;
    Slide selectedSlide;
    Slide previousSLide;
    int numofSelections;
    ImageView modelImage;
    int index = -1;
    ImageView currentImageViewer;
    SlideEditView currentSlideEditView;
    SlideEditView previousCss;
    String caption;
    ImageView previousImageViewer;

    public SlideShowModel(SlideShowMakerView initUI) {
        ui = initUI;
        slides = FXCollections.observableArrayList();
        reset();
        imageviews = new ArrayList();
    }

    public SlideShowMakerView getUI() {
        return ui;
    }

    // ACCESSOR METHODS

    public boolean isSlideSelected() {
        return selectedSlide != null;
    }

    public ObservableList<Slide> getSlides() {
        return slides;
    }

    public Slide getSelectedSlide() {
        return selectedSlide;
    }

    public String getTitle() {
        return title;
    }

    public String getCaption() {
        return caption;

    }

    public void setImageViewer(ImageView selected) {

        currentImageViewer = selected;

    }

    public ImageView getImageViewer() {
        return currentImageViewer;
    }

    public void setSlideEditView(SlideEditView selected) {

        currentSlideEditView = selected;

    }

    public SlideEditView getcurrentSlideEditView() {
        return currentSlideEditView;
    }

    // MUTATOR METHODS
    public void setSelectedSlide(Slide initSelectedSlide, Boolean selected, ImageView imageViewer, SlideEditView css) {

        previousSLide = selectedSlide;
        selectedSlide = initSelectedSlide;
        previousImageViewer = currentImageViewer;
        currentImageViewer = imageViewer;

        if (previousSLide != initSelectedSlide) {
            initSelectedSlide.setSelected(true);
            previousSLide.setSelected(false);
            previousImageViewer.setEffect(null);
        } else {

        }

        setImageViewer(imageViewer);
        setSlideEditView(css);

        for (Slide s : slides) {

            imageviews.add(new ImageView());
        }

        if (index == -1) {

            index = slides.indexOf(selectedSlide);
            imageviews.remove(index);
            imageviews.add(index, imageViewer);

            selectedSlide.setSelected(true);
            previousSLide.setSelected(false);

            imageViewer.setEffect(new DropShadow(90, Color.BLUE));
            css.getStyleClass().add(CSS_CLASS_SLIDE_SELECTED);

        } else if (index != slides.indexOf(selectedSlide) && index != -1) {
            imageviews.get(index).setEffect(null);
            index = slides.indexOf(selectedSlide);
            if (!(imageviews.contains(imageViewer))) {

                imageviews.remove(index);
                imageviews.add(index, imageViewer);
            }
            imageViewer.setEffect(new DropShadow(90, Color.BLUE));
            css.getStyleClass().add(CSS_CLASS_SLIDE_SELECTED);

                   // index= slides.indexOf(selectedSlide);
            selectedSlide.setSelected(true);

                      //previousSLide.setSelected(false);
        } else if (index == slides.indexOf(selectedSlide)) {
            index = slides.indexOf(selectedSlide);
            selectedSlide.setSelected(true);
            imageViewer.setEffect(new DropShadow(90, Color.BLUE));

        }

    }

    public void setTitle(String initTitle) {
        title = initTitle;
        ui.textField.setText(title);
    }

    // SERVICE METHODS
    /**
     * Resets the slide show to have no slides and a default title.
     */
    public void reset() {
        slides.clear();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        title = props.getProperty(LanguagePropertyType.DEFAULT_SLIDE_SHOW_TITLE);
        selectedSlide = null;
    }

    /**
     * Adds a slide to the slide show with the parameter settings.
     *
     * @param initImageFileName File name of the slide image to add.
     * @param initImagePath File path for the slide image to add.
     */
    public void addSlide(String initImageFileName,
            String initImagePath, String initCaption) {

        Slide slideToAdd = new Slide(initImageFileName, initImagePath, initCaption);
        slides.add(slideToAdd);
        selectedSlide = slideToAdd;
        imageviews.add(new ImageView());

        // setSelectedSlide(selectedSlide,true,currentImageViewer);
        ui.reloadSlideShowPane(this, currentImageViewer);
        //currentImageViewer.setEffect(new DropShadow(90, Color.BLUE));
        //slideToAdd.getSLideEditView().setEffect(new DropShadow(90, Color.BLUE));

    }

    public void upSlide() {
        //getImageViewer().setEffect(new DropShadow(90, Color.BLUE));
        Slide current = this.getSelectedSlide();

        int uindex = slides.indexOf(current);
       //imageviews.get(uindex).setEffect(new DropShadow(90, Color.BLUE));

        if (uindex > 0) {
            Slide previous = slides.get(uindex - 1);
            slides.set(uindex - 1, current);
            slides.set(uindex, previous);

            ui.reloadSlideShowPane(this, currentImageViewer);
        //this.currentImageViewer.setEffect(new DropShadow(90, Color.BLUE));
            //setSelectedSlide(selectedSlide,true,currentImageViewer);
            //current.getSLideEditView().setEffect(new DropShadow(90, Color.BLUE));
            // setSelectedSlide(selectedSlide,true,currentImageViewer,currentSlideEditView);
            //imageviews.get(index).setEffect(new DropShadow(90, Color.BLUE));

        }
    }

    public void downSlide() {
        ImageView currentView = getImageViewer();

        Slide current = this.getSelectedSlide();
        int dindex = slides.indexOf(current);

        if (dindex < ((slides.size() - 1))) {

            Slide after = slides.get(dindex + 1);
            slides.set(dindex + 1, current);
            slides.set(dindex, after);
       //setSelectedSlide(selectedSlide,true,currentImageViewer);

            ui.reloadSlideShowPane(this, currentImageViewer);
       //currentImageViewer.setEffect(new DropShadow(90, Color.BLUE));
            //setSelectedSlide(selectedSlide,true,currentImageViewer);
            // current.getSLideEditView().setEffect(new DropShadow(90, Color.BLUE));

            for (ImageView s : imageviews) {
                if (currentImageViewer == s) {
                    s.setEffect(new DropShadow(90, Color.BLUE));
                }
            }

        }
    }

    public void deleteSlide() {

        {

            Slide current = this.getSelectedSlide();
            System.out.println(slides.indexOf(current));

            if (slides.size() >= 0) {
                int dindex = slides.indexOf(current);
                if (dindex != -1) {
                    slides.remove(dindex);
//        getImageViewer().setEffect(new DropShadow(90, Color.BLUE));
                }

                ui.reloadSlideShowPane(this, currentImageViewer);

            }

        }

    }

    public void setSaveEnable() {
        ui.saveSlideShowButton.setDisable(false);
    }

    public Slide selectedSLide() {
        return this.getSelectedSlide();
    }
}
