package ssm.controller;

import properties_manager.PropertiesManager;
import static ssm.LanguagePropertyType.DEFAULT_IMAGE_CAPTION;
import static ssm.StartupConstants.DEFAULT_SLIDE_IMAGE;
import static ssm.StartupConstants.PATH_SLIDE_SHOW_IMAGES;
import ssm.error.ErrorHandler;
import ssm.model.Slide;
import ssm.model.SlideShowModel;
import ssm.view.SlideShowMakerView;

/**
 * This controller provides responses for the slideshow edit toolbar, which
 * allows the user to add, remove, and reorder slides.
 *
 * @author McKilla Gorilla & _Genius Genco ____________
 */
public class SlideShowEditController {

    // APP UI

    private SlideShowMakerView ui;
    public String defualt = "";
    ErrorHandler handle;

    //private String PATH_IMAGE_CAPTIONS;
    /**
     * This constructor keeps the UI for later.
     */
    public SlideShowEditController(SlideShowMakerView initUI) {
        ui = initUI;

    }

    /**
     * Provides a response for when the user wishes to add a new slide to the
     * slide show.
     */
    public void processAddSlideRequest() {
        SlideShowModel slideShow = ui.getSlideShow();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        slideShow.addSlide(DEFAULT_SLIDE_IMAGE, PATH_SLIDE_SHOW_IMAGES, defualt);
    }

    public void processUpSlideRequest() {
        SlideShowModel slideShow = ui.getSlideShow();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        slideShow.upSlide();

    }

    public void processDownSlideRequest() {
        SlideShowModel slideShow = ui.getSlideShow();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        slideShow.downSlide();
    }

    public void processSelectedSlide() {
        SlideShowModel slideShow = ui.getSlideShow();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        Slide current = slideShow.selectedSLide();
        current.getImagePath();

    }

    public void processDeleteSlide() {
        SlideShowModel slideShow = ui.getSlideShow();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        slideShow.deleteSlide();

    }
}
//    public void processError(String one, String two, String three){
//        handle =  new ErrorHandler(ui);
//        
//        handle.processError(DEFAULT_IMAGE_CAPTION, defualt, defualt);
//    }
//}
