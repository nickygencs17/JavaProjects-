package ssm.controller;

import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import ssm.LanguagePropertyType;
import static ssm.LanguagePropertyType.TOOLTIP_MOVE_DOWN;
import static ssm.LanguagePropertyType.TOOLTIP_MOVE_UP;
import static ssm.StartupConstants.CSS_CLASS_BOTTOM_TOOLBAR_BUTTON;
import static ssm.StartupConstants.CSS_CLASS_SLIDE_SHOW_EDIT_VBOX;
import static ssm.StartupConstants.ICON_NEXT;
import static ssm.StartupConstants.ICON_PREVIOUS;
import ssm.model.SlideShowModel;
import ssm.error.ErrorHandler;
import ssm.file.SlideShowFileManager;
import ssm.view.SlideShowMakerView;
import static ssm.StartupConstants.PATH_SLIDE_SHOWS;
import ssm.model.Slide;
import ssm.view.SlideEditView;
import ssm.view.Browser;

/**
 * This class serves as the controller for all file toolbar operations, driving
 * the loading and saving of slide shows, among other things.
 *
 * @author McKilla Gorilla & _Genius Genco ____________
 */
public class FileController {

    // WE WANT TO KEEP TRACK OF WHEN SOMETHING HAS NOT BEEN SAVED

    private boolean saved;

    // THE APP UI
    private SlideShowMakerView ui;

    ImageSelectionController imageController;
    VBox slideEditToolbar;

    // THIS GUY KNOWS HOW TO READ AND WRITE SLIDE SHOW DATA
    private SlideShowFileManager slideShowIO;
    Stage showSlideshow;
    SlideShowMakerView slideShowMakerView;

    Button previousButton;
    Button nextButton;
    HBox workspace;

    int clickCount = 0;
    Label captionLbl;
    Label titleLbl;

    /**
     * ;
     *
     * This default constructor starts the program without a slide show file
     * being edited.
     *
     * @param initSlideShowIO The object that will be reading and writing slide
     * show data.
     */
    public FileController(SlideShowMakerView initUI, SlideShowFileManager initSlideShowIO) {
        // NOTHING YET
        saved = true;
        ui = initUI;
        slideShowIO = initSlideShowIO;
    }

    public void markAsEdited() {
        saved = false;
        ui.updateToolbarControls(saved);
    }

    public void setSaved(boolean s) {
        saved = s;
    }

    /**
     * This method starts the process of editing a new slide show. If a pose is
     * already being edited, it will prompt the user to save it first.
     */
    public void handleNewSlideShowRequest() {
        try {
            clickCount = 0;
            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToMakeNew = true;

            Alert alert = new Alert(AlertType.CONFIRMATION);

            if (ui.getErrorHandler().getLanaguge() == 1) {
                alert.setTitle("New Slide Show");
                alert.setHeaderText("Do you want to make a new slide show?");
                alert.setContentText("Are you ok with this?");
            } else {
                alert.setTitle("Nueva presentación de diapositivas");
                alert.setHeaderText("¿Quieres hacer una nueva presentación de diapositivas ?");
                alert.setContentText("¿Estás bien con esto?");
            }

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                // ... user chose OK
                continueToMakeNew = true;
            } else {
                // ... user chose CANCEL or closed the dialog
                continueToMakeNew = false;
            }

            if (!saved && ui.getSlideShow().getSlides().size() != 0) {
                // THE USER CAN OPT OUT HERE WITH A CANCEL
                continueToMakeNew = promptToSave();
            }

            // IF THE USER REALLY WANTS TO MAKE A NEW COURSE
            if (continueToMakeNew) {
                // RESET THE DATA, WHICH SHOULD TRIGGER A RESET OF THE UI
                SlideShowModel slideShow = ui.getSlideShow();
                slideShow.reset();
                ui.reloadSlideShowPane(slideShow, null);
                saved = false;

                // REFRESH THE GUI, WHICH WILL ENABLE AND DISABLE
                // THE APPROPRIATE CONTROLS
                ui.updateToolbarControls(saved);

                // TELL THE USER THE SLIDE SHOW HAS BEEN CREATED
                // @todo
            }
        } catch (IOException ioe) {
            ErrorHandler eH = new ErrorHandler(ui);
            eH.processError(LanguagePropertyType.ERROR_PROPERTIES_NEW, ui.getSlideShow().getTitle(), ui.getSlideShow().getSelectedSlide().getImageFileName());
            //
        }
    }

    /**
     * This method lets the user open a slideshow saved to a file. It will also
     * make sure data for the current slideshow is not lost.
     */
    public void handleLoadSlideShowRequest() {
        try {
            clickCount = 0;

            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToOpen = true;
            if (!saved && ui.getSlideShow().getSlides().size() != 0) {
                // THE USER CAN OPT OUT HERE WITH A CANCEL
                continueToOpen = promptToSave();
            }

            // IF THE USER REALLY WANTS TO OPEN A POSE
            if (continueToOpen) {
                // GO AHEAD AND PROCEED MAKING A NEW POSE
                promptToOpen();
            }
        } catch (IOException ioe) {

            ErrorHandler eH1 = new ErrorHandler(ui);
            eH1.processError(LanguagePropertyType.ERROR_PROPERTIES_FILE_LOADING, ui.getSlideShow().getTitle(), ui.getSlideShow().getSelectedSlide().getImageFileName());
            //
        }
    }

    /**
     * This method will save the current slideshow to a file. Note that we
     * already know the name of the file, so we won't need to prompt the user.
     */
    public boolean handleSaveSlideShowRequest() {
        try {
            clickCount = 0;
            saved = true;
            // GET THE SLIDE SHOW TO SAVE
            SlideShowModel slideShowToSave = ui.getSlideShow();

            for (Node node : ui.getSlidesEditorPane().getChildren()) {
                if (node instanceof SlideEditView) {
                    SlideEditView index = (SlideEditView) node;
                    String caption = index.getCaptionTextField().getText();
                    index.getSlide().setCaption(caption);
                }
            }

            // SAVE IT TO A FILE
            if (ui.getSlideShow().getSlides().size() > -1) {
                slideShowIO.saveSlideShow(slideShowToSave);
                ui.updateToolbarControls(saved);

            }

            // MARK IT AS SAVED
            // AND REFRESH THE GUI, WHICH WILL ENABLE AND DISABLE
            // THE APPROPRIATE CONTROLS
            return true;
        } catch (IOException ioe) {

            ErrorHandler eH1 = new ErrorHandler(ui);
            eH1.processError(LanguagePropertyType.ERROR_PROPERTIES_FILE_SAVING, ui.getSlideShow().getTitle(), ui.getSlideShow().getSelectedSlide().getImageFileName());
            //
            return false;
        }
    }

    /**
     * This method will exit the application, making sure the user doesn't lose
     * any data first.
     */
    public void handleExitRequest() {
        try {
            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToExit = true;
            if (!saved && ui.getSlideShow().getSlides().size() != 0) {
                // THE USER CAN OPT OUT HERE
                continueToExit = promptToSave();
            }

            // IF THE USER REALLY WANTS TO EXIT THE APP
            if (continueToExit) {
                // EXIT THE APPLICATION
                System.exit(0);
            }
        } catch (IOException ioe) {

            ErrorHandler eH1 = new ErrorHandler(ui);
            eH1.processError(LanguagePropertyType.ERROR_PROPERTIES_EXIT, ui.getSlideShow().getTitle(), ui.getSlideShow().getSelectedSlide().getImageFileName());
            //

        }
    }

    public void handleViewRequest() {

        SlideShowModel slides = ui.getSlideShow();

        ObservableList<Slide> slides1 = slides.getSlides();
        int start = 0;
        int finish = slides1.size();
        String s = new String("");
        captionLbl = new Label(s);

        if (ui.getErrorHandler().getLanaguge() == 1) {
            titleLbl = new Label("Title: " + ui.getSlideShow().getTitle());
            s = "Caption: ";
        } else {
            titleLbl = new Label("Título: " + ui.getSlideShow().getTitle());
            s = "Subtítulo: ";
        }

        Group root = new Group();
        Stage stage = new Stage();
        stage.setResizable(false);

        stage.setTitle("Slide Show Viewer");
        stage.setWidth(500);
        stage.setHeight(550);

        Image imageNext = new Image(getClass().getResourceAsStream("Next.png"));
        Button buttonNext = new Button();
        buttonNext.setGraphic(new ImageView(imageNext));

        Image imagePrevious = new Image(getClass().getResourceAsStream("Previous.png"));
        Button buttonPrevious = new Button();
        buttonPrevious.setGraphic(new ImageView(imagePrevious));

        Scene scene = new Scene(new Group());
        VBox vbox = new VBox();
        HBox one = new HBox();
        HBox two = new HBox();
        HBox three = new HBox();
        HBox four = new HBox();

        BorderPane bordePane = new BorderPane();
        bordePane.setPadding(javafx.geometry.Insets.EMPTY); // space between elements and window border

        TilePane tileButtons = new TilePane(Orientation.HORIZONTAL);
        titleLbl.fontProperty().set(new Font("Arial", 30));
        titleLbl.alignmentProperty().setValue(Pos.CENTER);
        captionLbl.fontProperty().set(new Font("Arial", 20));
        captionLbl.alignmentProperty().setValue(Pos.CENTER);
        one.getChildren().add(titleLbl);
        two.getChildren().add(captionLbl);

        vbox.getChildren().add(one);

        tileButtons.setHgap(414.0);
        tileButtons.setVgap(10.0);
        tileButtons.getChildren().addAll(buttonPrevious, buttonNext);
        three.getChildren().add(tileButtons);
        vbox.getChildren().add(two);

        vbox.getChildren().add(three);

        if (slides1.size() - 1 > 0) {

            String slidePath = slides1.get(clickCount).getImagePath();
            String slideName = slides1.get(clickCount).getImageFileName();

            captionLbl.setText(s + slides1.get(clickCount).getCaption());

            System.out.println("file:" + slidePath + slideName);

            Image img = new Image("file:" + slidePath + slideName);
            ImageView imgView = new ImageView(img);
            imgView.setFitWidth(600);
            imgView.setFitHeight(350);

            StackPane stack = new StackPane();
            stack.getChildren().add(imgView);

            stack.translateXProperty()
                    .bind(scene.widthProperty().subtract(stack.widthProperty())
                            .divide(2));

            stack.translateYProperty()
                    .bind(scene.heightProperty().subtract(stack.heightProperty())
                            .divide(2).subtract(50));

            four.getChildren().add(stack);

            vbox.getChildren().add(four);

        }

        vbox.setSpacing(10);

        ((Group) scene.getRoot()).getChildren().add(vbox);
        stage.setScene(scene);
        stage.show();

        buttonNext.setOnMousePressed(e -> {

            if (clickCount < finish) {
                if (clickCount != finish - 1) {
                    clickCount++;
                    stage.close();
                    handleViewRequest();
                    buttonPrevious.setDisable(false);
                } else if (clickCount == finish - 1) {
                    buttonNext.setDisable(true);
                }
            }

        });
        buttonPrevious.setOnMousePressed(e -> {
            if (clickCount > start) {
                if (clickCount != start) {
                    clickCount--;
                    stage.close();
                    handleViewRequest();
                    buttonNext.setDisable(false);
                }
            } else if (clickCount == start) {
                buttonPrevious.setDisable(true);
            }

        });

    }

    /**
     * This helper method verifies that the user really wants to save their
     * unsaved work, which they might not want to do. Note that it could be used
     * in multiple contexts before doing other actions, like creating a new
     * pose, or opening another pose, or exiting. Note that the user will be
     * presented with 3 options: YES, NO, and CANCEL. YES means the user wants
     * to save their work and continue the other action (we return true to
     * denote this), NO means don't save the work but continue with the other
     * action (true is returned), CANCEL means don't save the work and don't
     * continue with the other action (false is retuned).
     *
     * @return true if the user presses the YES option to save, true if the user
     * presses the NO option to not save, false if the user presses the CANCEL
     * option to not continue.
     */
    private boolean promptToSave() throws IOException {
        // PROMPT THE USER TO SAVE UNSAVED WORK

        boolean saveWork = false;
        Alert alert = new Alert(AlertType.CONFIRMATION);

        if (ui.getErrorHandler().getLanaguge() == 1) {
            alert.setTitle("Save Slide Show");
            alert.setHeaderText("Do you want to save?");
            alert.setContentText("Are you ok with this?");
        } else {
            alert.setTitle("Guardar la presentación de diapositivas");
            alert.setHeaderText("¿Quieres ahorrar la presentación de diapositivas ?");
            alert.setContentText("¿Quieres ahorrar?");
        }

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            // ... user chose OK
            saveWork = true;
        } else {
            // ... user chose CANCEL or closed the dialog
            saveWork = false;
        }

        // IF THE USER SAID YES, THEN SAVE BEFORE MOVING ON
        if (saveWork) {
            SlideShowModel slideShow = ui.getSlideShow();
            slideShowIO.saveSlideShow(slideShow);
            saved = true;

        } // IF THE USER SAID CANCEL, THEN WE'LL TELL WHOEVER
        // CALLED THIS THAT THE USER IS NOT INTERESTED ANYMORE
        else if (!true) {
            return false;
        }

        // IF THE USER SAID NO, WE JUST GO ON WITHOUT SAVING
        // BUT FOR BOTH YES AND NO WE DO WHATEVER THE USER
        // HAD IN MIND IN THE FIRST PLACE
        return true;
    }

    /**
     * This helper method asks the user for a file to open. The user-selected
     * file is then loaded and the GUI updated. Note that if the user cancels
     * the open process, nothing is done. If an error occurs loading the file, a
     * message is displayed, but nothing changes.
     */
    private void promptToOpen() {
        // AND NOW ASK THE USER FOR THE COURSE TO OPEN
        FileChooser slideShowFileChooser = new FileChooser();
        slideShowFileChooser.setInitialDirectory(new File(PATH_SLIDE_SHOWS));
        File selectedFile = slideShowFileChooser.showOpenDialog(ui.getWindow());
        ImageView newImageView = null;
        // ONLY OPEN A NEW FILE IF THE USER SAYS OK
        if (selectedFile != null) {
            try {
                SlideShowModel slideShowToLoad = ui.getSlideShow();
                slideShowIO.loadSlideShow(slideShowToLoad, selectedFile.getAbsolutePath());
                ui.reloadSlideShowPane(slideShowToLoad, newImageView);
                saved = true;
                ui.updateToolbarControls(saved);
            } catch (Exception e) {
                ErrorHandler eH1 = new ErrorHandler(ui);

                eH1.processError(LanguagePropertyType.ERROR_DATA_FILE_LOADING, "Error", PATH_SLIDE_SHOWS);
                //
            }
        }
    }

    /**
     * This mutator method marks the file as not saved, which means that when
     * the user wants to do a file-type operation, we should prompt the user to
     * save current work first. Note that this method should be called any time
     * the pose is changed in some way.
     */
    public void markFileAsNotSaved() {
        saved = false;
    }

    /**
     * Accessor method for checking to see if the current pose has been saved
     * since it was last editing. If the current file matches the pose data,
     * we'll return true, otherwise false.
     *
     * @return true if the current pose is saved to the file, false otherwise.
     */
    public boolean isSaved() {
        return saved;
    }

    public void setClickCount(int i) {
        clickCount = i;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void handleViewRequestWeb() throws IOException {

        String title = ui.getSlideShow().getTitle();
        Stage s = new Stage();
        Scene scene = new Scene(new Browser(ui.getSlideShow().getSlides(), title));
        s.setScene(scene);
        s.show();

    }

    public ObservableList<Slide> getSlideShow() {
        return ui.getSlideShow().getSlides();
    }
}
