package ssm;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import xml_utilities.InvalidXMLFileFormatException;
import properties_manager.PropertiesManager;
import static ssm.LanguagePropertyType.TITLE_WINDOW;
import static ssm.StartupConstants.PATH_DATA;
import static ssm.StartupConstants.PROPERTIES_SCHEMA_FILE_NAME;
import static ssm.StartupConstants.UI_PROPERTIES_FILE_NAME_ENG;
import static ssm.StartupConstants.UI_PROPERTIES_FILE_NAME_SPA;
import ssm.error.ErrorHandler;
import ssm.file.SlideShowFileManager;
import ssm.view.SlideShowMakerView;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.image.Image;

/**
 * SlideShowMaker is a program for making custom image slideshows. It will allow
 * the user to name their slideshow, select images to use, select captions for
 * the images, and the order of appearance for slides.
 *
 * @author McKilla Gorilla & _Genius Genco ____________
 */
public class SlideShowMaker extends Application {

    // THIS WILL PERFORM SLIDESHOW READING AND WRITING

    SlideShowFileManager fileManager = new SlideShowFileManager();
    public int language = 1;
    // THIS HAS THE FULL USER INTERFACE AND ONCE IN EVENT
    // HANDLING MODE, BASICALLY IT BECOMES THE FOCAL
    // POINT, RUNNING THE UI AND EVERYTHING ELSE
    SlideShowMakerView ui;
    private Object Pos;
    //public int language;
    ErrorHandler errorHandler;

    @Override
    public void start(Stage primaryStage) throws Exception {
        // LOAD APP SETTINGS INTO THE GUI AND START IT UP

        String os = System.getProperty("os.name");
        System.out.println(os);

        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("lightning-bolt-32.png")));

        List<String> choices = new ArrayList<>();
        choices.add("English");
        choices.add("Spanish");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("English", choices);

        dialog.setTitle("Language");
        dialog.setHeaderText("Please Select a Language");
        dialog.setContentText("Choose your Language:");
        dialog.getDialogPane().setStyle("    -fx-padding-left: 10px;\n" +
"    -fx-padding-right: 20px;\n" +
"    -fx-spacing: 70px;\n" +
"    -fx-alignment: CENTER;\n" +
"    -fx-font-family: verdana, sans-serif;\n" +
"    -fx-font-size: 13px;\n" +
"    -fx-font-weight: bold;\n" +
"    -fx-background-color: rgb(204,204,0);");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(letter -> System.out.println("Your choice: " + letter));

        if (false == result.isPresent()) {
            System.exit(0);
        } else if (null != result.get()) {
            switch (result.get()) {

                case "English": {
                    boolean success = loadPropertiesENG();
                    if (success) {

                        language = 1;

                        this.setLanguage(language);
                        ui = new SlideShowMakerView(fileManager, language);
                        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("lightning-bolt-32.png")));
                        PropertiesManager props = PropertiesManager.getPropertiesManager();
                        String appTitle = props.getProperty(TITLE_WINDOW);

                        // NOW START THE UI IN EVENT HANDLING MODE
                        ui.startUI(primaryStage, appTitle);
                        ui.getErrorHandler().setLanguage(1);

                    } // THERE WAS A PROBLEM LOADING THE PROPERTIES FILE
                    else {
                        // LET THE ERROR HANDLER PROVIDE THE RESPONSE
                        ui = new SlideShowMakerView(fileManager, language);
                        ErrorHandler errorHandler = ui.getErrorHandler();
                        errorHandler.errorHandlerSetLanguage(1);
                        errorHandler.processError(LanguagePropertyType.ERROR_DATA_FILE_LOADING, "Error:", "Language Not Loaded Correctly");
                        System.exit(0);
                    }
                    break;
                }
                case "Spanish": {
                    boolean success = loadPropertiesSPA();
                    if (success) {
                        language = 2;
                        this.setLanguage(language);
                        ui = new SlideShowMakerView(fileManager, language);

                        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("lightning-bolt-32.png")));
                        PropertiesManager props = PropertiesManager.getPropertiesManager();
                        String appTitle = props.getProperty(TITLE_WINDOW);

                        // NOW START THE UI IN EVENT HANDLING MODE
                        ui.startUI(primaryStage, appTitle);

                    } // THERE WAS A PROBLEM LOADING THE PROPERTIES FILE
                    else {
                        // LET THE ERROR HANDLER PROVIDE THE RESPONSE
                        ui = new SlideShowMakerView(fileManager, language);
                        ErrorHandler errorHandler = ui.getErrorHandler();
                        errorHandler.errorHandlerSetLanguage(2);
                        errorHandler.processError(LanguagePropertyType.ERROR_DATA_FILE_LOADING, "Error:", "Idioma no se carga correctamente");
                        System.exit(0);
                    }
                    break;
                }

            }
        } else {
            System.out.println("New");

        }

    }

    /**
     * Loads this application's properties file, which has a number of settings
     * for initializing the user interface.
     *
     * @return true if the properties file was loaded successfully, false
     * otherwise.
     */
    public boolean loadPropertiesENG() {
        try {
            // LOAD THE SETTINGS FOR STARTING THE APP

            language = 1;
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            props.addProperty(PropertiesManager.DATA_PATH_PROPERTY, PATH_DATA);
            props.loadProperties(UI_PROPERTIES_FILE_NAME_ENG, PROPERTIES_SCHEMA_FILE_NAME);
            return true;
        } catch (InvalidXMLFileFormatException ixmlffe) {
            // SOMETHING WENT WRONG INITIALIZING THE XML FILE
            ErrorHandler eH = ui.getErrorHandler();
            eH.processError(LanguagePropertyType.ERROR_DATA_FILE_LOADING, "Error:", "Language Not Loaded Correctly");
            return false;
        }
    }

    public boolean loadPropertiesSPA() {
        try {
            // LOAD THE SETTINGS FOR STARTING THE APP
            language = 2;
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            props.addProperty(PropertiesManager.DATA_PATH_PROPERTY, PATH_DATA);
            props.loadProperties(UI_PROPERTIES_FILE_NAME_SPA, PROPERTIES_SCHEMA_FILE_NAME);
            return true;
        } catch (InvalidXMLFileFormatException ixmlffe) {
            // SOMETHING WENT WRONG INITIALIZING THE XML FILE
            ErrorHandler eH = ui.getErrorHandler();
            eH.processError(LanguagePropertyType.ERROR_DATA_FILE_LOADING, "Error:", "Idioma no se carga correctamente");
            return false;
        }
    }

    /**
     * This is where the application starts execution. We'll load the
     * application properties and then use them to build our user interface and
     * start the window in event handling mode. Once in that mode, all code
     * execution will happen in response to user requests.
     *
     * @param args This application does not use any command line arguments.
     */
    public static void main(String[] args) {

        com.sun.javafx.runtime.VersionInfo.getRuntimeVersion();
        launch(args);
    }

    public int getLanguage() {

        return language;
    }

    public void setLanguage(int i) {

        language = i;
    }
}
