var i = 0, imgsrc = new Array(), preload = new Array();
imgsrc[0] = "imgs/nick.jpg";
imgsrc[1] = "imgs/nick2.jpg";
imgsrc[2] = "imgs/nick3.jpg";
imgsrc[3] = "imgs/nick4.jpg";

for (var j = 0; j < imgsrc.length; j++)
{
    preload[j] = new Image;
    preload[j].src = imgsrc[j];
}
function mode(param)
{
    smode = param;
}
function startSlideshow()
{
    if (smode == "play")
    {
        document.getElementById("play").hidden = "hidden";
        document.getElementById("pause").hidden = "";
        document.getElementById("slideshow").src = imgsrc[i];
        document.getElementById("previous").hidden = "hidden";
        document.getElementById("next").hidden = "hidden";
        i++;
        setTimeout("startSlideshow()", 1500);
    }
    else if (smode == "pause")
    {
        document.getElementById("pause").hidden = "hidden";
        document.getElementById("play").hidden = "";
        document.getElementById("play").value = "Resume";
        document.getElementById("previous").hidden = "";
        document.getElementById("next").hidden = "";
    }
    else if (smode == "stop")
    {
        document.getElementById("play").disabled = "";
        document.getElementById("play").value = "Play";
        document.getElementById("pause").disabled = "disabled";
        document.getElementById("slideshow").src = imgsrc[i];
        i = 0;
    }
    else if (smode == "next")
    {
        if (i < (imgsrc.length - 1))
        {
            i++;
            document.getElementById("slideshow").src = imgsrc[i];
        }
        else
        {
            i = 0;
            document.getElementById("slideshow").src = imgsrc[i];
        }
    }
    else if (smode == "previous")
    {
        if (i > 0)
        {
            i--;
            document.getElementById("slideshow").src = imgsrc[i];
        }
        else
        {
            i = imgsrc.length - 1;
            document.getElementById("slideshow").src = imgsrc[i];
        }
    }
    if (i == imgsrc.length)
    {
        i = 0;
    }
}
