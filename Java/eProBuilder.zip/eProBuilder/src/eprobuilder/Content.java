/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Content {
    
    
    String type;
    
    public Content(String initType){
        type = initType;
    }
    
    public String getContentType(){
        return type;
    }
    
    public void setContent(String initType){
        type = initType;
    }
    
}
