/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Attributes {
    
    
    String type;
    
    public Attributes(String initType){
        type = initType;
    }
    
    public String getAttributeType(){
        return type;
    }
    
    public void setAttributeType(String initType){
        type = initType;
    }
    
}
