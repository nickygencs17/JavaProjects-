/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class HyperLink extends Content {
    String linkText;
    String link;

    
     public HyperLink(String initType, String initText,String initLink){
        super(initType);
        
        linkText=initText;
        link = initLink;
      
     }
  
    public void setLinkText(String initText){
        linkText=initText;
    }
      public void setLink(String initLink){
        link = initLink;
    }
     public String getLinkText(){
        return linkText;
    }
      public String getLink(){
        return link;
    }
    
}