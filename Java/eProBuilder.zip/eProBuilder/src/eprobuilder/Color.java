
package eprobuilder;



/**
 *
 * @author nicholasgenco
 */
public class Color extends Attributes {
    
    
    String text;
    
    public Color(String initType, String initOption){
        super(initType);
        
        text = initOption;
       
    }
    
    public String getFontText(){
        return text;
    }
    
    public void setFontText(String initText){
        text = initText;
    }
    
}