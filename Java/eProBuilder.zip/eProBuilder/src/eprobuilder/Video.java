/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Video extends Content {
    String filePath;
    String fileName;
    String caption;
    int Height;
    int Width;
    
    
     public Video(String initType, String initFilePath, String initfileName, int initHeight, int intWidth, String initCaption){
        super(initType);
        fileName = initfileName;
        filePath= initFilePath;
        caption = initCaption;
        Height= initHeight;
        Width= intWidth;
      
        
     }
    public void setWidth(int initWidth){
        Width= initWidth;
    }
    public void setHeight(int initHeight){
        Height= initHeight;
    }
    public void setFilePath(String initFilePath){
        filePath= initFilePath;
    }
   public int getWidth(){
        return Width;
    }
    public int getHeight(){
         return Height;
    }
    public String getFilePath(){
        return filePath;
    }
     public void setFileName(String initFileName){
        fileName= initFileName;
    }
   public String getFileName(){
        return fileName;
    }
       public void setCaption(String initCaption){
        caption= initCaption;
    }
   public String getCaption(){
        return caption;
    }
   
}
