/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class BannerImage extends Attributes{
    
    String filePath;
    String fileName;
    int Height;
    int Width;
 
    
    
     public BannerImage(String initType, String intitfileName, String initFilePath, int initHeight, int intWidth){
        super(initType);
        fileName = intitfileName;
        filePath= initFilePath;
        Height= initHeight;
        Width= intWidth;
      
        
     }
    public void setWidth(int initWidth){
        Width= initWidth;
    }
    public void setHeight(int initHeight){
        Height= initHeight;
    }
    public void setFilePath(String initFilePath){
        filePath= initFilePath;
    }
     public void setFileName(String initFileName){
        fileName= initFileName;
    }
      public int getWidth(){
        return Width;
    }
    public int getHeight(){
         return Height;
    }
    public String getFilePath(){
        return filePath;
    }
    public String getFileName(){
        return fileName;
    }
}

