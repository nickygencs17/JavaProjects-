/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Paragraph extends Content {
    String paragraph;
    String font;
 
    
    
     public Paragraph(String initType, String intitfont,String initParagraph){
        super(initType);
        
        paragraph=initParagraph;
        font = intitfont;
      
     }
  
    public void setParagraph(String initParagraph){
        paragraph=initParagraph;
    }
    public String getParagraph(){
        return paragraph;
    }
      public void setFont(String initFont){
        font=initFont;
    }
    public String getFont(){
        return font;
    }
}
