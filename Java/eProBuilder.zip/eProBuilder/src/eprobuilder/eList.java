/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

import java.util.List;

/**
 *
 * @author nicholasgenco
 */
public class eList extends Content {
   
    int numListItems;
    List<String> items;
    String listType;
    
    
     public eList(String initType,String initListType, int initnumListItems, List<String> intitems){
        super(initType);
        
        listType= initListType;
        numListItems= initnumListItems;
        items= intitems;
      
        
     }
    public void setListType(String initListType){
        listType= initListType;
    }
    public void setNumListItems(int initnumListItems){
        numListItems= initnumListItems;
    }
    public void setListItems(List<String> intitems){
         items= intitems;
    }
    
    public String getListType(){
        return listType;
    }
    public int getNumListItems(){
        return numListItems;
    }
    public List<String> getListItems(){
         return items;
    }
}
