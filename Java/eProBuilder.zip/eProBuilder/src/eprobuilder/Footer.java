
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Footer extends Attributes {
    
    
    String text;
    
    public Footer(String initType, String initText){
        super(initType);
        
        text = initText;
       
    }
    
    public String getFooterText(){
        return text;
    }
    
    public void setFooterText(String initText){
        text = initText;
    }
    
}
