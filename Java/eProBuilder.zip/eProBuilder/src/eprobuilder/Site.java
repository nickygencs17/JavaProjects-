/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
import java.util.ArrayList;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class Site extends Tab {

    public String filePath;
    public int key;
    public String title;
    List<Content> contents;
    List<VBox> vboxes;
    List<SlideShow> currentSlideShows;
    List<eList> Lists;
    List <Attributes> Attributes;

    public Site(String inittitle, String initFilePath, int initkey, List<Content> intitcontent, List<VBox> initvboxes, List<SlideShow> initcurrentSlideShows, List<eList> initList,List <Attributes>initAttributes) {
        title = inittitle;
        vboxes = initvboxes;
        currentSlideShows = initcurrentSlideShows;
        key = initkey;
        filePath = initFilePath;
        contents = intitcontent;
        Lists = initList;
        Attributes = initAttributes;

    }

    public List<Content> getContentList() {

        return contents;
    }

    public int getKey() {

        return key;
    }

    public String getFilePathType() {

        return filePath;

    }

    public void setFilePath(String s) {

        filePath = s;
    }
     public String gettitle() {

        return title;

    }

    public void settitle(String s) {

        title = s;
    }

    public void setContentList(List<Content> initContent) {

        contents = initContent;
    }

    public void setKey(int initKey) {

        key = initKey;

    }

    public void setVboxList(List<VBox> initvboxes) {

        vboxes = initvboxes;
    }

    public List<VBox> getVboxList() {

        return vboxes;
    }

    public List<SlideShow> getSSList() {

        return currentSlideShows;
    }

    public void setLists(List<eList> initList) {

        Lists = initList;
    }

    public List<eList> getLists() {

        return Lists;
    }
   public void setALists(List <Attributes> initAttributes) {

        Attributes = initAttributes;
    }

    public List <Attributes> getALists() {

        return Attributes;
    }

}
