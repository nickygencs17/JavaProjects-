/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class Header extends Content {
    String headerText;
    String headerSize;

    
     public Header(String initType, String initHeaderSize,String initHeaderText){
        super(initType);
        
        headerText=initHeaderText;
        headerSize = initHeaderSize;
      
     }
  
    public void setHeaderText(String initHeaderText){
        headerText=initHeaderText;
    }
      public void setHeaderSize(String initHeaderSize){
        headerSize=initHeaderSize;
    }
     public String getHeaderText(){
        return headerText;
    }
      public String getHeaderSize(){
        return headerSize;
    }
    
}
