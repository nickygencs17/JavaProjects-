/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

import java.util.List;

/**
 *
 * @author nicholasgenco
 */
public class SlideShow extends Content {
    List<Slide> slides;
    String title;
   
    
     public SlideShow(String initType, String initTitle, List<Slide> initslides){
        super(initType);
       
       slides= initslides;
       title = initTitle;
   
        
     }

    public void setSlides(List<Slide>  initslides){
       slides= initslides;
    }
  
    public List<Slide>  getSlides(){
        return slides;
    }
     public void setTitle(String inittitle){
       title=inittitle;
    }
  
    public String  getTtile(){
        return title;
    }
  
  
}
