package eprobuilder;

/**
 * This class represents a single slide in a slide show.
 * 
 * @author McKilla Gorilla & _____________
 */
public class Slide {
   
    String imagePath;
    String caption;
     
    /**
     * Constructor, it initializes all slide data.
     * @param initImageFileName File name of the image.
     * 
     * @param initImagePath File path for the image.
     * 
     * @param initCaption Textual caption to appear under the image.
     */
    public Slide(String initImagePath, String initCaption) {
	
	imagePath = initImagePath;
	caption = initCaption;
    }
    
    // ACCESSOR METHODS
   
    public String getImagePath() { return imagePath; }
    public String getCaption() { return caption; }
    
    // MUTATOR METHODS
  
    public void setImagePath(String initImagePath) {
	imagePath = initImagePath;
    }
    
    public void setCaption(String initCaption) {
	caption = initCaption;
    }
    
}
