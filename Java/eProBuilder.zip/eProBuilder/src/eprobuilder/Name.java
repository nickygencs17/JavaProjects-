
package eprobuilder;



/**
 *
 * @author nicholasgenco
 */
public class Name extends Attributes {
    
    
    String text;
    
    public Name(String initType, String initOption){
        super(initType);
        
        text = initOption;
       
    }
    
    public String getNameText(){
        return text;
    }
    
    public void setNameText(String initText){
        text = initText;
    }
    
}