/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

import static eprobuilder.eProBuilder.dialogEditHeader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Pair;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.json.JsonWriterFactory;
import javax.json.stream.JsonGenerator;

/**
 *
 * @author nicholasgenco
 */
public class eProBuilder extends Application {

    private Object scene;
    public boolean toggleEdit = false;
    public int numSites = 6;
    public static Stage window;
    Scene scene1, scene2;
    TabPane tabPaneEdit = new TabPane();
    TabPane tabPaneSite = new TabPane();
    public static String filePathVideo = "";
    public static String fileNameVideo = "";
    public static String filePathSlideShow = "";
    public static String fileNameSlideShow = "";
    public static String filePathImage = "";
    public static String fileNameImage = "";
    List<Site> sites = new ArrayList();
    List<VBox> vboxes = new ArrayList();
    Site site;
    Site previousSite;
    String currentcontent = "";
    List<Attributes> Attributes = new ArrayList();
    Name currentName;
    int numofslideshows = 0;
    int numoflists = 0;
    VBox current;
    VBox previous;
    HBox slideCurrent;
    HBox slidePrevious;
    boolean publish;
    String currentTitle;
    Site currentSite;
    Paragraph currentP;
    eImage currentImg;
    eList currentL;
    SlideShow currentSS;
    Header currentH;
    Video currentV;
    boolean load;

    @Override
    public void start(Stage primaryStage) {

        window = primaryStage;
//    openFileBtn.setGraphic(new ImageView("/pathToOpenFileBtnIcon.png"));
//    snapshotBtn.setGraphic(new ImageView("/pathToSnapshotBtnIcon.png"));
//    printBtn.setGraphic(new ImageView("/pathToPrintBtnIcon.png"));
        BorderPane root = loadPane();
        //root.setPrefSize(1200,1200); 

        scene1 = new Scene(root, 1200, 1200);

        Button button2 = new Button("todo//site, go back to scene 1");
        button2.setOnAction(e -> window.setScene(scene1));

        //Layout 2
        StackPane layout2 = new StackPane();
        layout2.getChildren().add(button2);
        scene2 = new Scene(layout2, 600, 300);

        // primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("lightning-bolt-32.png")));
        primaryStage.setTitle("eProfile Builder");

        primaryStage.setScene(scene1);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static void dialogCheckPressed(String s) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Check:");
        alert.setHeaderText(null);
        alert.setContentText(s + " was pressed");
        alert.showAndWait();

    }

    public boolean getToggleEdit() {
        return toggleEdit;
    }

    public void setToggleEdit(boolean f) {
        f = toggleEdit;
    }

    public BorderPane loadPane() {

        BorderPane root = new BorderPane();
        root.getStylesheets().add("eProStyle.css");

        System.out.println("Working Directory = "
                + System.getProperty("user.dir"));
        //FlowPane fp = new FlowPane();
        Button newBtn = new Button("New");
        Button loadBtn = new Button("Load");
        Button saveBtn = new Button("Save");
        Button saveAsBtn = new Button("Save As");
        Button exportBtn = new Button("Export");
        Button exitBtn = new Button("Exit");
        Button addBtn = new Button("Add");
        Button removeBtn = new Button("Remove");
        boolean toggle = getToggleEdit();

        saveBtn.setDisable(true);
        saveAsBtn.setDisable(true);
        exportBtn.setDisable(true);
        addBtn.setDisable(true);
        removeBtn.setDisable(true);
        Button enterTitleBtn = new Button("Change title");
        Button enterNameBtn = new Button("Change Student Name");
        Button bannerImgBtn = new Button("Change Banner Image");
        Button footerTextBtn = new Button("Change Footer Text");
        Button selectLayoutBtn = new Button("Change Layout");
        Button fontBtn = new Button("Change Font ");
        Button colorBtn = new Button("Change Color");

        Button addImgBtn = new Button("Add Image");
        Button addParagraphBtn = new Button("Add Paragraph");
        Button addListBtn = new Button("Add List");
        Button addHeaderBtn = new Button("Add Header");
        Button addVideoBtn = new Button("Add Video");
        Button addSlideShowBtn = new Button("Add SlideShow");
        Button addInlineLinkBtn = new Button("Add Inline Link");

        enterTitleBtn.setDisable(true);
        enterNameBtn.setDisable(true);
        bannerImgBtn.setDisable(true);
        footerTextBtn.setDisable(true);
        selectLayoutBtn.setDisable(true);
        fontBtn.setDisable(true);
        colorBtn.setDisable(true);

        addImgBtn.setDisable(true);
        addParagraphBtn.setDisable(true);
        addListBtn.setDisable(true);
        addHeaderBtn.setDisable(true);
        addVideoBtn.setDisable(true);
        addSlideShowBtn.setDisable(true);
        addInlineLinkBtn.setDisable(true);
        final ToggleGroup group = new ToggleGroup();

        ToggleButton toggleEditView = new ToggleButton("Page Edit");
        toggleEditView.setToggleGroup(group);
        toggleEditView.setSelected(true);

        ToggleButton toggleSiteView = new ToggleButton("Site Viewer");
        toggleSiteView.setToggleGroup(group);

        final ToggleGroup group1 = new ToggleGroup();

        ToggleButton toggleEditView1 = new ToggleButton("Page Edit");
        toggleEditView1.setToggleGroup(group);

        ToggleButton toggleSiteView1 = new ToggleButton("Site Viewer");
        toggleSiteView.setDisable(true);
        toggleSiteView1.setToggleGroup(group);
        toggleSiteView1.setSelected(true);

        ToolBar toolBarTop = new ToolBar();  //Creates our tool-bar to hold the buttons.
        ToolBar toolBarLeftSite = new ToolBar();  //Creates our tool-bar to hold the buttons.
        ToolBar toolBarLeftEdit = new ToolBar();
        ToolBar toolBarRightEdit = new ToolBar();

        toolBarRightEdit.getItems().addAll(addImgBtn, addParagraphBtn, addListBtn, addHeaderBtn, addVideoBtn, addSlideShowBtn, addInlineLinkBtn);
        toolBarRightEdit.setOrientation(Orientation.VERTICAL);

        toolBarLeftEdit.getItems().addAll(addBtn, removeBtn, new Separator(), enterTitleBtn, enterNameBtn, bannerImgBtn, footerTextBtn, selectLayoutBtn, colorBtn, fontBtn, new Separator(), toggleSiteView);
        toolBarLeftEdit.setOrientation(Orientation.VERTICAL);

        toolBarTop.getItems().addAll(newBtn, loadBtn, saveBtn, saveAsBtn, new Separator(), exportBtn, exitBtn);
        toolBarTop.setOrientation(Orientation.HORIZONTAL);

        toolBarLeftSite.getItems().addAll(toggleEditView1);
        toolBarLeftSite.setOrientation(Orientation.VERTICAL);

        newBtn.setOnAction(e -> {
            tabPaneEdit.getTabs().clear();
            tabPaneSite.getTabs().clear();
            sites.clear();
            currentTitle = dialogEnterTitle();
            String s = dialogEnterStudentName();
            currentName = new Name("Name", s);
            Attributes.add(currentName);//0

            String[] strings = dialogBannerImage();
            Integer width = Integer.parseInt(strings[2]);
            Integer height = Integer.parseInt(strings[3]);
            Attributes.add(new BannerImage("BannerImage", strings[0], strings[1], height, width));//1
            s = dialogEnterFooter();
            Attributes.add(new Footer("Footer", s));//2
            s = dialogSelectLayout();
            Attributes.add(new Layout("Layout", s));//3
            s = dialogSelectFont();
            Attributes.add(new eFont("Font", s));//4
            s = dialogSelectColor();
            Attributes.add(new Color("Color", s));//5

            saveBtn.setDisable(false);
            saveAsBtn.setDisable(false);
            exportBtn.setDisable(false);
            addBtn.setDisable(false);
            removeBtn.setDisable(false);

            enterTitleBtn.setDisable(false);
            enterNameBtn.setDisable(false);
            bannerImgBtn.setDisable(false);
            footerTextBtn.setDisable(false);
            selectLayoutBtn.setDisable(false);
            fontBtn.setDisable(false);
            colorBtn.setDisable(false);

            addImgBtn.setDisable(false);
            addParagraphBtn.setDisable(false);
            addListBtn.setDisable(false);
            addHeaderBtn.setDisable(false);
            addVideoBtn.setDisable(false);
            addSlideShowBtn.setDisable(false);
            addInlineLinkBtn.setDisable(false);
            toggleSiteView.setDisable(false);

            List<Content> newList = new ArrayList();
            List<VBox> newVBoxList = new ArrayList();
            List<SlideShow> currentSlideShows = new ArrayList();
            List<eList> lists = new ArrayList();

            currentTitle = dialogEnterTitle();

            site = new Site(currentTitle, "Path", 1, newList, newVBoxList, currentSlideShows, lists, Attributes);

            sites.add(site);
            numSites++;

            makeTabPanesEdit(site);

        });

        loadBtn.setOnAction(e -> {
            numofslideshows = 0;
            numoflists = 0;
            tabPaneEdit.getTabs().clear();
            tabPaneSite.getTabs().clear();
            sites.clear();
            load = true;
            tabPaneEdit.getTabs().clear();
            tabPaneSite.getTabs().clear();
            sites.clear();
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Json Files", "*.json"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {

                try {
                    List<Site> sitesss = eproLoad(selectedFile.getAbsolutePath());

                    for (Site s : sitesss) {
                        site = s;
                        currentSite = s;
                        sites.add(site);

                        for (Content c : s.getContentList()) {
                            if (c instanceof eImage) {
                                eImage img = (eImage) c;
                                currentImg = img;
                                addImgBtn.fire();

                            } else if (c instanceof Video) {
                                Video v = (Video) c;
                                currentV = v;
                                addVideoBtn.fire();

                            } else if (c instanceof Paragraph) {

                                Paragraph p = (Paragraph) c;
                                currentP = p;
                                addParagraphBtn.fire();

                            } else if (c instanceof Header) {

                                Header p = (Header) c;
                                currentH = p;
                                addHeaderBtn.fire();

                            } else if (c instanceof SlideShow) {
                                SlideShow slideShow = (SlideShow) c;
                                currentSS = slideShow;

                                numofslideshows++;
                                addSlideShowBtn.fire();

                            } else if (c instanceof eList) {
                                eList lsit = (eList) c;
                                currentL = lsit;

                                numoflists++;
                                addListBtn.fire();
                            }

                        }
                        makeTabPanesEdit(site);
                    }

                } catch (IOException ex) {
                    Logger.getLogger(eProBuilder.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                //todo exception Handler 
            }

            load = false;

        });

        saveBtn.setOnAction((ActionEvent e) -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showSaveDialog(null);

            if (selectedFile != null) {
                try {
                    saveSlideShow(sites, selectedFile.getAbsolutePath(), selectedFile.getName());
                } catch (IOException ex) {
                    Logger.getLogger(eProBuilder.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                //todo exception Handler 
            }
        });
        saveAsBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showSaveDialog(null);

            if (selectedFile != null) {
                try {
                    saveSlideShow(sites, selectedFile.getAbsolutePath(), selectedFile.getName());
                } catch (IOException ex) {
                    Logger.getLogger(eProBuilder.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                //todo exception Handler 
            }

        });
        exportBtn.setOnAction(e -> {
            window.setScene(scene2);

        });
        exitBtn.setOnAction(e -> {

            //exit
            Platform.exit();
        });

        addBtn.setOnAction(e -> {

            List<Content> newList = new ArrayList();
            List<VBox> newVBoxList = new ArrayList();
            List<SlideShow> currentSlideShows = new ArrayList();
            List<eList> lists = new ArrayList();

            currentTitle = dialogEnterTitle();

            site = new Site(currentTitle, "Path", 1, newList, newVBoxList, currentSlideShows, lists, Attributes);

            sites.add(site);
            numSites++;

            makeTabPanesEdit(site);

        });
        removeBtn.setOnAction(e -> {

            if (tabPaneEdit.getTabs().size() < 0) {
                int s = tabPaneEdit.getSelectionModel().getSelectedIndex();
                tabPaneEdit.getTabs().remove(s);
                sites.remove(s);
            }

            if (numSites > 0) {
                numSites--;
            }
            site = null;
            makeTabPanesEdit(site);

        });
        toggleEditView.setOnAction(e -> {

            root.setLeft(toolBarLeftEdit);
            root.setCenter(makeTabPanesEdit(site));

        });
        toggleSiteView.setOnAction(e -> {
            root.setLeft(toolBarLeftSite);
            root.setCenter(makeTabPanesSite());
            root.setRight(null);
        });
        toggleEditView1.setOnAction(e -> {

            root.setLeft(toolBarLeftEdit);
            root.setRight(toolBarRightEdit);
            root.setCenter(makeTabPanesEdit(site));

        });
        toggleSiteView1.setOnAction(e -> {

            root.setLeft(toolBarLeftSite);
            root.setCenter(makeTabPanesSite());

        });

        enterTitleBtn.setOnAction(e -> {
            String s = dialogEnterTitle();
            System.out.println(s);

            tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex()).setText(s);

        });
        enterNameBtn.setOnAction((ActionEvent e) -> {

            String s = dialogEnterStudentName();
            if (s != null) {
                Name n = new Name("Name", s);
                Attributes.set(0, n);
            }
        });

        bannerImgBtn.setOnAction(e -> {

            String[] strings = dialogBannerImage();
            if (strings.length <= 0) {
                Integer width = Integer.parseInt(strings[2]);
                Integer height = Integer.parseInt(strings[3]);
                BannerImage bi = new BannerImage("BannerImage", strings[0], strings[1], height, width);
                Attributes.set(1, bi);
            }
        });
        footerTextBtn.setOnAction(e -> {
            String s = dialogEnterFooter();
            if (s != null) {
                Footer f = new Footer("Footer", s);
                Attributes.set(2, f);
            }
        });
        selectLayoutBtn.setOnAction(e -> {
            String s = dialogSelectLayout();
            if (s != null) {
                Layout l = new Layout("Layout", s);//3
                Attributes.set(3, l);
            }
        });
        fontBtn.setOnAction(e -> {
            String s = dialogSelectFont();
            if (s != null) {
                eFont f = new eFont("Font", s);//4
                Attributes.set(4, f);
            }
        });
        colorBtn.setOnAction(e -> {
            String s = dialogSelectColor();
            if (s != null) {
                Color c = new Color("Color", s);//5
                Attributes.set(5, c);
            }

        });
        addImgBtn.setOnAction(e -> {

            if (load == false) {
                currentcontent = "image";
                String[] strings = dialogAddImage();
                Integer width = Integer.parseInt(strings[2]);
                Integer height = Integer.parseInt(strings[3]);

                tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                if (site == null) {
                    site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                } else {
                    site.getContentList().get((site.getContentList().size() - 1)).setContent(currentcontent);
                }

                site.getContentList().add(new eImage("Image", strings[0], strings[1], height, width, strings[4], strings[5]));
                reloadPane(strings, site.getContentList(), "Image", -1);
            } else {
                currentSite.getContentList().add(currentImg);
                reloadPane(new String[5], currentSite.getContentList(), "Image", -1);
            }

        });
        addParagraphBtn.setOnAction(e -> {
            if (load == false) {
                String[] strings = dialogAddParagraph();
                tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                if (site == null) {
                    site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                } else {
                    site.getContentList().get((site.getContentList().size() - 1)).setContent(currentcontent);
                }
                site.getContentList().add(new Paragraph("Paragraph", strings[0], strings[1]));
                reloadPane(strings, site.getContentList(), "Paragraph", -1);
            } else {
                currentSite.getContentList().add(currentP);
                reloadPane(new String[5], currentSite.getContentList(), "Paragraph", -1);
            }
        });
        addListBtn.setOnAction(e -> {
            if (load == false) {
                addList();
            } else {
                currentSite.getContentList().add(currentL);
                currentSite.getLists().add(currentL);

                reloadPane(new String[5], currentSite.getContentList(), "List", -1);

            }

        });
        addHeaderBtn.setOnAction(e -> {
            if (load == false) {
                String[] strings = dialogAddHeader();
                if (!tabPaneEdit.getTabs().isEmpty()) {
                    tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                    if (site == null) {
                        site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                    } else {
                        site.getContentList().get((site.getContentList().size() - 1)).setContent(currentcontent);
                    }
                    site.getContentList().add(new Header("Header", strings[0], strings[1]));
                    reloadPane(strings, site.getContentList(), "Header", -1);
                }
            } else {
                currentSite.getContentList().add(currentH);
                reloadPane(new String[5], currentSite.getContentList(), "Header", -1);

            }
        });

        addVideoBtn.setOnAction(e -> {
            if (load == false) {
                currentcontent = "video";
                String[] strings = dialogStart();
                Integer width = Integer.parseInt(strings[2]);
                Integer height = Integer.parseInt(strings[3]);

                tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                if (site == null) {
                    site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                } else {
                    site.getContentList().get((site.getContentList().size() - 1)).setContent(currentcontent);
                }
                site.getContentList().add(new Video("Video", strings[0], strings[1], height, width, strings[4]));
                reloadPane(strings, site.getContentList(), "Video", -1);
            } else {
                currentSite.getContentList().add(currentV);
                reloadPane(new String[5], currentSite.getContentList(), "Video", -1);
            }

        });
        addSlideShowBtn.setOnAction(e -> {
            if (load == false) {
                slideShowDialog();
            } else {
                currentSite.getContentList().add(currentSS);
                currentSite.getSSList().add(currentSS);

                reloadPane(new String[5], currentSite.getContentList(), "SlideShow", -1);
            }

        });
        addInlineLinkBtn.setOnAction(e -> {
            dialogInlineAddHyperLink();

        });

        BorderPane mainPane = new BorderPane();

        tabPaneEdit = makeTabPanesEdit(site);

        tabPaneEdit.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Tab> ov, Tab t, Tab t1) -> {
            System.out.println("Tab Selection changed");
            tabPaneEdit.selectionModelProperty().get();
            System.out.println("Tab index:" + tabPaneEdit.getSelectionModel().getSelectedIndex());

            if (site != null) {
                site = previousSite;

            }

        });

        root.setCenter(tabPaneEdit);
        root.setTop(toolBarTop);
        root.setLeft(toolBarLeftEdit);
        root.setRight(toolBarRightEdit);
        tabPaneEdit.getStylesheets().add("eProStyle.css");
        return root;
    }

    public TabPane makeTabPanesEdit(Site f) {
        if (site != previousSite) {
            tabPaneEdit.getTabs().clear();
            if (tabPaneEdit.getChildrenUnmodifiable().size() < 0) {
                tabPaneEdit.getChildrenUnmodifiable().clear();
                numSites = 0;
            }

            for (int i = 0; sites.size() > i; i++) {

                String filenameNew = (sites.get(i).gettitle());
                HBox hbox = new HBox();
                List<Content> content = new ArrayList();
                Site newsite = sites.get(i);

                if (newsite.getVboxList().size() != 0) {
                    ScrollPane sp = new ScrollPane();
                    FlowPane fp = new FlowPane();
                    fp.getChildren().addAll(newsite.getVboxList());
                    sp.setContent(fp);
                    newsite.setContent(sp);
                } else {
                    newsite.setContent(hbox);
                    hbox.setStyle("-fx-background-color: #4895ec;");
                    newsite.setText(sites.get(i).gettitle());
                    hbox.setOnMousePressed(e -> {

                    });
                }

                //hbox.setAlignment(Pos.TOP_LEFT);
                tabPaneEdit.getTabs().add(newsite);

            }
        }
        tabPaneEdit.getStylesheets().add("eProStyle.css");
        return tabPaneEdit;
    }

    public TabPane makeTabPanesSite() {

        tabPaneSite.getTabs().clear();
        String os = System.getProperty("os.name");

        String curDir = System.getProperty("user.dir");

        System.out.print(curDir);

        String fileStart = "file://";
        if (os.contains("Windows")) {

            String replaced = curDir.replace("\\", "/");
            curDir = replaced;
            fileStart = "file:///";

        }

        if (tabPaneSite.getChildrenUnmodifiable().size() < 0) {
            tabPaneSite.getChildrenUnmodifiable().clear();
            numSites = 0;
        }

        for (Site s : sites) {
            String siteString = makeSites(s);

            FileWriter fWriter = null;
            BufferedWriter writer = null;
            try {
                fWriter = new FileWriter(currentName.getNameText() + "/sites/" + s.gettitle() + ".html");
                writer = new BufferedWriter(fWriter);
                writer.write(siteString);
                writer.newLine(); //this is not actually needed for html files - can make your code more readable though 
                writer.close(); //make sure you close the writer object 
            } catch (Exception e) {
                //catch any exceptions here
            }

            final WebView browser = new WebView();
            final WebEngine webEngine = browser.getEngine();
            Tab tab = new Tab();

            //hbox.getChildren().forEach();
            System.out.print(fileStart + curDir + "/" + currentName.getNameText() + "/sites/" + s.gettitle() + ".html");

            webEngine.load(fileStart + curDir + "/" + currentName.getNameText() + "/sites/" + s.gettitle() + ".html");

            //add the web view to the scene
            //hbox.setAlignment(Pos.TOP_LEFT);
            tab.setContent(browser);

//        hbox.setOnMousePressed(e -> {
//            dialogCheckPressed("HBOX: ");
//        });
            tab.setText(s.gettitle());

            tabPaneSite.getTabs().add(tab);

        }
        return tabPaneSite;
    }

    public static String dialogEnterTitle() {
        TextInputDialog dialog = new TextInputDialog("Title");
        dialog.setTitle("Set Title");
        dialog.setHeaderText("Enter Title");
        dialog.setContentText("Please enter Title:");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> System.out.println("Your name: " + name));
        if (result.isPresent()) {
            return result.get();
        } else {

            return null;
        }
    }

    public static String dialogEnterFooter() {
        TextInputDialog dialog = new TextInputDialog("Footer");
        dialog.setTitle("Text Input: Footer");
        dialog.setHeaderText("Enter Footer");
        dialog.setContentText("Please enter your Footer Text:");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> System.out.println("Your name: " + name));
        if (result.isPresent()) {
            return result.get();
        } else {

            return null;
        }

    }

    public static String dialogEnterStudentName() {
        TextInputDialog dialog = new TextInputDialog("Name");
        dialog.setTitle("Enter Name");
        dialog.setHeaderText("Enter Name");
        dialog.setContentText("Please enter your name:");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> {
            System.out.println("Your name: " + name);

        });
        if (result.isPresent()) {
            return result.get();
        } else {

            return null;
        }

    }

    public static String dialogSelectLayout() {
        List<String> choices = new ArrayList<>();
        choices.add("navTopLeft");
        choices.add("navMiddle");
        choices.add("navLeft");
        choices.add("navMiddleLeft");
        choices.add("navTopMiddle");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("navTopLeft", choices);
        dialog.setTitle("Choose a Layout");
        dialog.setHeaderText("Choose a Layout");
        dialog.setContentText("Choose a Layout:");

// Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();

// The Java 8 way to get the response value (with lambda expression).
        if (result.isPresent()) {
            return result.get();
        } else {

            return null;
        }

    }

    public static String dialogSelectFont() {
        List<String> choices = new ArrayList<>();
        choices.add("TimesRoman");
        choices.add("Verdana");
        choices.add("Arial");
        choices.add("Courier");
        choices.add("Helvetica");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("TimesRoman", choices);
        dialog.setTitle("Choose Font");
        dialog.setHeaderText("Choose a Font");
        dialog.setContentText("Choose a Font");

        // Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();

        // The Java 8 way to get the response value (with lambda expression).
        result.ifPresent(letter -> {
            System.out.println("Your choice: " + letter);

        });
        if (result.isPresent()) {
            return result.get();
        } else {

            return null;
        }
    }

    public static String[] dialogAddHeader() {
        // Create the custom dialog.
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Add Header");
        dialog.setHeaderText("Add Header");

        ComboBox comboBox = new ComboBox();
        comboBox.getItems().addAll(
                "h1",
                "h2",
                "h3",
                "h4",
                "h5");
//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField password = new TextField();
        password.setPromptText("Text:");

        grid.add(new Label("Size of Header:"), 0, 0);
        grid.add(comboBox, 1, 0);
        grid.add(new Label("Text:"), 0, 1);
        grid.add(password, 1, 1);

// Do some validation (using the Java 8 lambda syntax).
        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> password.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(comboBox.getValue().toString(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
        });
        String[] strings = new String[2];
        strings[0] = comboBox.getValue().toString();
        strings[1] = password.getText();

        for (int i = 0; i < strings.length; i++) {
            System.out.println(strings[i]);
        }
        return strings;
    }

    private void SaveFile(String content, File file) {
        try {
            FileWriter fileWriter = null;

            fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.close();
        } catch (IOException ex) {
            Logger.getLogger("hello").log(Level.SEVERE, null, ex);
        }

    }

    public static String dialogSelectColor() {
        List<String> choices = new ArrayList<>();
        choices.add("Black/White");
        choices.add("Red/Black");
        choices.add("Yellow");
        choices.add("Green");
        choices.add("Blue");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("Blue", choices);
        dialog.setTitle("Pick a Color");
        dialog.setHeaderText("Choose a Color");
        dialog.setContentText("Choose your Color:");

        // Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();

        // The Java 8 way to get the response value (with lambda expression).
        if (result.isPresent()) {
            result.ifPresent(letter -> System.out.println("Your choice: " + letter));

            return result.get();
        } else {
            return null;
        }
    }

    public static String[] dialogAddParagraph() {

        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Add Paragraph");
        dialog.setHeaderText("Add Paragraph");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        ComboBox cb = new ComboBox();
        cb.getItems().addAll(
                "Font 1",
                "Font 2",
                "Font 3");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextArea password = new TextArea();
        password.setPromptText("Paragraph:");
        grid.add(cb, 1, 1);
        grid.add(new Label("Paragraph:"), 0, 2);
        grid.add(new Label("Font:"), 0, 1);
        grid.add(password, 1, 2);

        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        password.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> password.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return password.getText();
            }
            return null;
        });

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println(result.toString());
        });
        String[] strings = new String[2];

        strings[0] = cb.getValue().toString();
        strings[1] = password.getText();

        return strings;

    }

    public static String[] dialogAddParagraphEdit(String[] s) {

        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Add Paragraph");
        dialog.setHeaderText("Add Paragraph");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        ComboBox cb = new ComboBox();
        cb.getItems().addAll(
                "Font 1",
                "Font 2",
                "Font 3");
        cb.setValue(s[0]);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextArea password = new TextArea();
        password.setText(s[1]);
        grid.add(cb, 1, 1);
        grid.add(new Label("Paragraph:"), 0, 2);
        grid.add(new Label("Font:"), 0, 1);
        grid.add(password, 1, 2);

        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        password.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> password.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return password.getText();
            }
            return null;
        });

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println(result.toString());
        });
        String[] strings = new String[2];

        strings[0] = cb.getValue().toString();
        strings[1] = password.getText();

        return strings;

    }

    public static String[] dialogAddHyperLink() {
        // Create the custom dialog.
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Add HyperLink");
        dialog.setHeaderText("Add HyperLink");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Link", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Text to be HyperLinked");
        TextField password = new TextField();
        password.setPromptText("Link:");

        grid.add(new Label("Text to be HyperLinked:"), 0, 0);
        grid.add(username, 1, 0);
        grid.add(new Label("Link:"), 0, 1);
        grid.add(password, 1, 1);

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
        });
        String[] strings = new String[2];
        strings[0] = username.getText();
        strings[1] = password.getText();

        return strings;

    }

    public static String[] dialogInlineAddHyperLink() {
        // Create the custom dialog.
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Add HyperLink");
        dialog.setHeaderText("Add HyperLink");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Link", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Text to be HyperLinked");
        TextField password = new TextField();
        password.setPromptText("Link:");

        grid.add(new Label("Text to be HyperLinked:"), 0, 0);
        grid.add(username, 1, 0);
        grid.add(new Label("Link:"), 0, 1);
        grid.add(password, 1, 1);

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
        });
        String[] strings = new String[2];
        strings[0] = username.getText();
        strings[1] = password.getText();

        return strings;

    }

//    String[] strings = new String[5];
//        strings[0] = filePathVideo;
//        strings[1] = fileNameVideo;
//        strings[2] = username.getText();
//        strings[3] = password.getText();
//        strings[4] = tf.getText();
//    site.getContentList().add(new Video("Video", strings[0], strings[1], height, width, strings[4]));
//            reloadPane(strings, site.getContentList(), "Video", -1);
    public static String[] dialogVideoEdit(String[] s) {

        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.getDialogPane().setPrefSize(800, 500);
        dialog.setTitle("Add Video");
        dialog.setHeaderText("Add Video");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        Button file = new Button("Browse: ");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField(s[2]);
        username.setPromptText("Width");
        TextField password = new TextField(s[3]);
        password.setPromptText("Height");
        TextField tf = new TextField(s[4]);
        grid.add(new Label("File:"), 0, 0);

        grid.add(file, 1, 0);
        grid.add(new Label("Width:"), 0, 1);
        grid.add(password, 1, 1);
        grid.add(new Label("Height:"), 0, 2);
        grid.add(username, 1, 2);
        grid.add(new Label("Caption:"), 0, 3);
        grid.add(tf, 1, 3);

        Label f = new Label();
        f.setText(s[1]);
        grid.add(f, 2, 0);

        username.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = username.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    username.setText(username.getText().substring(0, username.getText().length() - 1));
                }
            }
        });
        password.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = password.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    password.setText(password.getText().substring(0, password.getText().length() - 1));
                }
            }
        });

        file.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(window);
            FileChooser.ExtensionFilter extFilter
                    = new FileChooser.ExtensionFilter("Video files (*.mp4)", "*.mp4");

            fileChooser.getExtensionFilters().add(extFilter);
            if (selectedFile != null) {
                filePathVideo = selectedFile.getPath();
                fileNameVideo = selectedFile.getName();
                f.setText(fileNameVideo);

            } else {
                //todo exception Handler 
            }
        });

// Enable/Disable login button depending on whether a username was entered.
// Do some validation (using the Java 8 lambda syntax).
        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Width=" + usernamePassword.getKey() + ", Height=" + usernamePassword.getValue());
        });

        String[] strings = new String[5];
        strings[0] = filePathVideo;
        strings[1] = fileNameVideo;
        strings[2] = username.getText();
        strings[3] = password.getText();
        strings[4] = tf.getText();

        return strings;

    }

    public static String[] dialogStart() {

        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.getDialogPane().setPrefSize(800, 500);
        dialog.setTitle("Add Video");
        dialog.setHeaderText("Add Video");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        Button file = new Button("Browse: ");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Width");
        TextField password = new TextField();
        password.setPromptText("Height");
        TextField tf = new TextField("Caption:");

        username.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = username.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    username.setText(username.getText().substring(0, username.getText().length() - 1));
                }
            }
        });
        password.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = password.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    password.setText(password.getText().substring(0, password.getText().length() - 1));
                }
            }
        });

        grid.add(new Label("File:"), 0, 0);

        grid.add(file, 1, 0);
        grid.add(new Label("Width:"), 0, 1);
        grid.add(password, 1, 1);
        grid.add(new Label("Height:"), 0, 2);
        grid.add(username, 1, 2);
        grid.add(new Label("Caption:"), 0, 3);
        grid.add(tf, 1, 3);

        file.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(window);
            FileChooser.ExtensionFilter extFilter
                    = new FileChooser.ExtensionFilter("Video files (*.mp4)", "*.mp4");

            fileChooser.getExtensionFilters().add(extFilter);
            if (selectedFile != null) {
                filePathVideo = selectedFile.getPath();
                fileNameVideo = selectedFile.getName();
                grid.add(new Label(selectedFile.getName()), 2, 0);

            } else {
                //todo exception Handler 
            }
        });

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Width=" + usernamePassword.getKey() + ", Height=" + usernamePassword.getValue());
        });

        String[] strings = new String[5];
        strings[0] = filePathVideo;
        strings[1] = fileNameVideo;
        strings[2] = username.getText();
        strings[3] = password.getText();
        strings[4] = tf.getText();

        return strings;

    }

    public static String[] dialogAddImage() {

        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.getDialogPane().setPrefSize(800, 500);
        dialog.setTitle("Add Image");
        dialog.setHeaderText("Add Image");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        ComboBox cb = new ComboBox();
        cb.getItems().addAll(
                "Left",
                "Right",
                "Center");
//

        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        Button file = new Button("Browse: ");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Width");
        TextField password = new TextField();
        TextField captionText = new TextField();
        password.setPromptText("Height");
        grid.add(new Label("Caption:"), 0, 3);
        grid.add(captionText, 1, 3);
        grid.add(new Label("Float:"), 0, 4);
        grid.add(cb, 1, 4);

        username.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = username.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    username.setText(username.getText().substring(0, username.getText().length() - 1));
                }
            }
        });
        password.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = password.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    password.setText(password.getText().substring(0, password.getText().length() - 1));
                }
            }
        });

        grid.add(new Label("File:"), 0, 0);

        grid.add(file, 1, 0);
        grid.add(new Label("Width:"), 0, 1);
        grid.add(password, 1, 1);
        grid.add(new Label("Height:"), 0, 2);
        grid.add(username, 1, 2);

        file.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {
                filePathImage = selectedFile.getPath();
                fileNameImage = selectedFile.getName();
                grid.add(new Label(selectedFile.getName()), 2, 0);

            } else {
                //todo exception Handler 
            }
        });

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Width=" + usernamePassword.getKey() + ", Height=" + usernamePassword.getValue());
        });
        String[] strings = new String[6];
        strings[0] = filePathImage;
        strings[1] = fileNameImage;
        strings[2] = username.getText();
        strings[3] = password.getText();
        strings[4] = captionText.getText();
        strings[5] = cb.getValue().toString();

        return strings;

    }

    public static String[] dialogBannerImage() {

        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.getDialogPane().setPrefSize(600, 300);
        dialog.setTitle("Add Image");
        dialog.setHeaderText("Add Image");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);

        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        Button file = new Button("Browse: ");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Width");
        TextField password = new TextField();

        password.setPromptText("Height");

        username.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = username.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    username.setText(username.getText().substring(0, username.getText().length() - 1));
                }
            }
        });
        password.lengthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                if (newValue.intValue() > oldValue.intValue()) {
                    char ch = password.getText().charAt(oldValue.intValue());
                    // Check if the new character is the number or other's
                    if (!(ch >= '0' && ch <= '9')) {
                        // if it's not number then just setText to previous one
                        password.setText(password.getText().substring(0, password.getText().length() - 1));
                    }
                }
            }

        });

        grid.add(new Label("File:"), 0, 0);

        grid.add(file, 1, 0);
        grid.add(new Label("Width:"), 0, 1);
        grid.add(password, 1, 1);
        grid.add(new Label("Height:"), 0, 2);
        grid.add(username, 1, 2);

        file.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {
                filePathImage = selectedFile.getPath();
                fileNameImage = selectedFile.getName();
                grid.add(new Label(selectedFile.getName()), 2, 0);

            } else {
                //todo exception Handler 
            }
        });

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Width=" + usernamePassword.getKey() + ", Height=" + usernamePassword.getValue());
        });
        String[] strings = new String[6];
        strings[0] = filePathImage;
        strings[1] = fileNameImage;
        strings[2] = username.getText();
        strings[3] = password.getText();

        return strings;

    }

    public List<String> addList() {
        List<String> strings = new ArrayList();
        List<String> listItems = new ArrayList(0);

        List<HBox> hboxess = new ArrayList();
        ScrollPane sp = new ScrollPane();
        FlowPane fp = new FlowPane();
        VBox vbox = new VBox();

        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(window);

        ToolBar toolBarTop = new ToolBar();
        ToolBar toolBarLeft = new ToolBar();

        Button addListItemBtn = new Button("Add List Item");
        Button removeListItemBtn = new Button("Remove List Item");
        Button upButton = new Button("Up");
        Button downButton = new Button("Down");

        Button addToEproBtn = new Button("Add to Epro");
        Button cancelBtn = new Button("Cancel");
        ComboBox cb = new ComboBox();

        cb.getItems().addAll(
                "ol",
                "ul");
        cb.setValue("ol");
//

        boolean idk = false;

        addListItemBtn.setOnAction(e -> {

            HBox hbox = new HBox(20);
            Integer counter = hboxess.size() + 1;
            hbox.getChildren().addAll(new Label(counter.toString() + "   "), new TextField());
            hbox.setPrefSize(400, 40);

            hboxess.add(hbox);

            vbox.getChildren().clear();
            vbox.getChildren().addAll(hboxess);
            fp.getChildren().clear();
            fp.getChildren().add(vbox);

        });
        removeListItemBtn.setOnAction(e -> {
            if (hboxess.size() > 0) {
                hboxess.remove(hboxess.size() - 1);
            }
            vbox.getChildren().clear();
            vbox.getChildren().addAll(hboxess);
            fp.getChildren().clear();
            fp.getChildren().add(vbox);
        });

        addToEproBtn.setOnAction(e -> {
            for (int i = 0; hboxess.size() > i; i++) {

                for (int j = 0; hboxess.get(i).getChildren().size() > j; j++) {

                    if (hboxess.get(i).getChildren().get(j) instanceof TextField) {
                        TextField l = (TextField) hboxess.get(i).getChildren().get(j);
                        listItems.add(l.getText());

                    }

                }

            }

            String[] strings1 = new String[0];
            if (!listItems.isEmpty() || cb.getValue() != null) {
                eList newList = new eList("List", cb.getValue().toString(), listItems.size(), listItems);

                numoflists++;

                tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                if (site == null) {
                    site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                }

                site.getContentList().add(newList);
                site.getLists().add(newList);

                dialog.close();
                reloadPane(strings1, site.getContentList(), "List", -1);
            }

        });
        cancelBtn.setOnAction(e -> {
            dialog.close();
        });

        toolBarLeft.getItems().addAll(addListItemBtn, removeListItemBtn);
        toolBarLeft.setOrientation(Orientation.VERTICAL);

        toolBarTop.getItems().addAll(addToEproBtn, cancelBtn, new Separator(), new Label("List Type: "), cb, new Separator());
        toolBarTop.setOrientation(Orientation.HORIZONTAL);

        BorderPane bp = new BorderPane();

        if (hboxess != null) {
            fp.getChildren().addAll(hboxess);
        }

        sp.setContent(fp);

        bp.setLeft(toolBarLeft);
        bp.setTop(toolBarTop);

        bp.setCenter(sp);

        Scene dialogScene = new Scene(bp, 700, 500);

        dialog.setScene(dialogScene);
        dialog.show();

        return strings;

    }

    public void slideShowDialog() {

        List<Slide> slides = new ArrayList();
        List<String> filenames = new ArrayList();
        List<String> comments = new ArrayList();
        publish = false;

        ScrollPane sp = new ScrollPane();
        FlowPane fp = new FlowPane();
        List<HBox> slideHbox = new ArrayList();

        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(window);

        ToolBar toolBarTop = new ToolBar();
        ToolBar toolBarLeft = new ToolBar();
        String os = System.getProperty("os.name");

        String curDir = System.getProperty("user.dir") + "/src/eprobuilder";

        System.out.print(curDir);

        String fileStart = "file://";
        if (os.contains("Windows")) {

            String replaced = curDir.replace("\\", "/");
            curDir = replaced;
            fileStart = "file:///";

        }

        Button addSlideBtn = new Button("Add Slide");
        Button removeSlideBtn = new Button("Remove Slide");
        Button upButton = new Button("Up");
        Button downButton = new Button("Down");
        Label titleLabel = new Label("Enter Title");
        Button addToEproBtn = new Button("Add to Epro");
        Button cancelBtn = new Button("Cancel");
        TextField titleField = new TextField();
        boolean idk = false;

        addSlideBtn.setOnAction(e -> {

            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {

                HBox hbox = new HBox();
                String filestart = "file://";
                System.out.print(selectedFile.getAbsolutePath());
                if (os.contains("Windows")) {
                    filestart = "file:///";
                }
                hbox.setOnMousePressed(f -> {
                    if (hbox != slideCurrent) {
                        slidePrevious = slideCurrent;
                        slideCurrent = hbox;

                        slideCurrent.setStyle("-fx-border-color:black;");
                        slideCurrent.setStyle("-fx-background-color:red;"
                                + "-fx-border-color: #000000;");
                        if (slidePrevious != null) {
                            slidePrevious.setStyle("-fx-border-color:white;");
                            slidePrevious.setStyle("-fx-background-color:white;"
                                    + "-fx-border-color: #000000;");
                        }

                    }

                });

                String path = filestart + selectedFile.getAbsolutePath();

                Image image = new Image(path, 200.0, 200.0, idk, idk);
                TextField tf = new TextField();
                ImageView imageView = new ImageView(image);
                hbox.getChildren().addAll(imageView, new Label("Content"), tf);
                slideHbox.add(hbox);
                fp.getChildren().clear();
                fp.getChildren().addAll(slideHbox);

                filenames.add(path);

            }

        });
        removeSlideBtn.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);
            if (slideHbox != null) {
                slideHbox.remove(index);
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);

        });

        upButton.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);
            if (index != 0) {
                int indexNext = slideHbox.indexOf(slideCurrent) - 1;

                HBox hboxOfcurrent = slideCurrent;
                HBox hboxOfnext = slideHbox.get(indexNext);

                if (slideHbox != null) {
                    slideHbox.set(indexNext, hboxOfcurrent);
                    slideHbox.set(index, hboxOfnext);
                }
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);
        });

        downButton.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);

            if (index != (slideHbox.size() - 1)) {
                int indexNext = slideHbox.indexOf(slideCurrent) + 1;

                HBox hboxOfcurrent = slideCurrent;
                HBox hboxOfnext = slideHbox.get(indexNext);

                if (slideHbox != null) {
                    slideHbox.set(indexNext, hboxOfcurrent);
                    slideHbox.set(index, hboxOfnext);
                }
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);
        });

        addToEproBtn.setOnAction(e -> {

            for (int i = 0; slideHbox.size() > i; i++) {

                for (int j = 0; slideHbox.get(i).getChildren().size() > j; j++) {

                    if (slideHbox.get(i).getChildren().get(j) instanceof TextField) {
                        TextField l = (TextField) slideHbox.get(i).getChildren().get(j);
                        comments.add(l.getText());

                        System.out.println(l.getText());
                    }

                }
                slides.add(new Slide(filenames.get(i), comments.get(i)));
            }

            publish = true;

            String[] strings = new String[0];
            SlideShow currentSlide = new SlideShow("SlideShow", titleField.getText(), slides);
            numofslideshows++;

            tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
            if (site == null) {
                site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

            }

            site.getContentList().add(currentSlide);
            site.getSSList().add(currentSlide);

            dialog.close();
            reloadPane(strings, site.getContentList(), "SlideShow", -1);

        });
        cancelBtn.setOnAction(e -> {
            dialog.close();
        });

        toolBarLeft.getItems().addAll(addSlideBtn, removeSlideBtn, upButton, downButton);
        toolBarLeft.setOrientation(Orientation.VERTICAL);

        toolBarTop.getItems().addAll(addToEproBtn, cancelBtn, new Separator(), titleLabel, titleField);
        toolBarTop.setOrientation(Orientation.HORIZONTAL);

        BorderPane bp = new BorderPane();

        fp.getChildren().addAll(slideHbox);

        sp.setContent(fp);

        bp.setLeft(toolBarLeft);
        bp.setTop(toolBarTop);

        bp.setCenter(sp);

        Scene dialogScene = new Scene(bp, 1000, 600);

        dialog.setScene(dialogScene);
        dialog.show();

    }

    public static String[] dialogAddImageEdit(String[] s) {

        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.getDialogPane().setPrefSize(800, 500);
        dialog.setTitle("Add Image");
        dialog.setHeaderText("Add Image");

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        ComboBox cb = new ComboBox();
        cb.getItems().addAll(
                "Left",
                "Right",
                "Center");

        cb.setValue(s[5]);

        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        Button file = new Button("Browse: ");
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField(s[3]);
        username.setPromptText("Width");
        TextField password = new TextField(s[2]);
        TextField captionText = new TextField(s[4]);
        password.setPromptText("Height");
        grid.add(new Label("Caption:"), 0, 3);
        grid.add(captionText, 1, 3);
        grid.add(new Label("Float:"), 0, 4);
        grid.add(cb, 1, 4);
        grid.add(new Label("File:"), 0, 0);

        grid.add(file, 1, 0);
        grid.add(new Label("Width:"), 0, 1);
        grid.add(password, 1, 1);
        grid.add(new Label("Height:"), 0, 2);
        grid.add(username, 1, 2);
        Label y = new Label(s[1]);
        grid.add(y, 2, 0);

        username.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = username.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    username.setText(username.getText().substring(0, username.getText().length() - 1));
                }
            }
        });
        password.lengthProperty().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            if (newValue.intValue() > oldValue.intValue()) {
                char ch = password.getText().charAt(oldValue.intValue());
                // Check if the new character is the number or other's
                if (!(ch >= '0' && ch <= '9')) {
                    // if it's not number then just setText to previous one
                    password.setText(password.getText().substring(0, password.getText().length() - 1));
                }
            }
        });

        file.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {
                filePathImage = selectedFile.getPath();
                fileNameImage = selectedFile.getName();
                y.setText(fileNameImage);

            } else {
                //todo exception Handler 
            }
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Width=" + usernamePassword.getKey() + ", Height=" + usernamePassword.getValue());
        });
        String[] strings = new String[6];
        strings[0] = filePathImage;
        strings[1] = fileNameImage;
        strings[2] = username.getText();
        strings[3] = password.getText();
        strings[4] = captionText.getText();
        strings[5] = cb.getValue().toString();

        return strings;

    }

    public static String[] dialogEditHeader(String[] s) {
        // Create the custom dialog.
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Add Header");
        dialog.setHeaderText("Add Header");

        ComboBox comboBox = new ComboBox();
        comboBox.getItems().addAll(
                "h1",
                "h2",
                "h3",
                "h4",
                "h5");
        comboBox.setValue(s[0]);

//
// Set the button types.
        ButtonType loginButtonType = new ButtonType("Add", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField password = new TextField();

        password.setText(s[1]);

        grid.add(new Label("Size of Header:"), 0, 0);
        grid.add(comboBox, 1, 0);
        grid.add(new Label("Text:"), 0, 1);
        grid.add(password, 1, 1);

// Do some validation (using the Java 8 lambda syntax).
        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> password.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(comboBox.getValue().toString(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
        });
        String[] strings = new String[2];
        strings[0] = comboBox.getValue().toString();
        strings[1] = password.getText();

        for (int i = 0; i < strings.length; i++) {
            System.out.println(strings[i]);
        }
        return strings;
    }

    public void slideShowDialogEdit(int indexg, SlideShow h) {

        List<Slide> slides = new ArrayList();
        List<String> filenames = new ArrayList();
        List<String> comments = new ArrayList();
        publish = false;
        boolean idk = true;

        ScrollPane sp = new ScrollPane();
        FlowPane fp = new FlowPane();
        List<HBox> slideHbox = new ArrayList();

        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(window);

        ToolBar toolBarTop = new ToolBar();
        ToolBar toolBarLeft = new ToolBar();
        String os = System.getProperty("os.name");

        String curDir = System.getProperty("user.dir") + "/src/eprobuilder";

        System.out.print(curDir);

        String fileStart = "file://";
        if (os.contains("Windows")) {

            String replaced = curDir.replace("\\", "/");
            curDir = replaced;
            fileStart = "file:///";

        }

        Button addSlideBtn = new Button("Add Slide");
        Button removeSlideBtn = new Button("Remove Slide");
        Button upButton = new Button("Up");
        Button downButton = new Button("Down");
        Label titleLabel = new Label("Title");
        Button addToEproBtn = new Button("Add to Epro");
        Button cancelBtn = new Button("Cancel");
        TextField titleField = new TextField();
        titleField.setText(h.getTtile());

        for (Slide z : h.getSlides()) {

            HBox hbox = new HBox();
            String filestart = "file://";
            if (os.contains("Windows")) {
                filestart = "file:///";
            }
            hbox.setOnMousePressed(f -> {
                if (hbox != slideCurrent) {
                    slidePrevious = slideCurrent;
                    slideCurrent = hbox;

                    slideCurrent.setStyle("-fx-border-color:black;");
                    slideCurrent.setStyle("-fx-background-color:red;"
                            + "-fx-border-color: #000000;");
                    if (slidePrevious != null) {
                        slidePrevious.setStyle("-fx-border-color:white;");
                        slidePrevious.setStyle("-fx-background-color:white;"
                                + "-fx-border-color: #000000;");
                    }

                }

            });

            String path = z.getImagePath();

            Image image = new Image(path, 200.0, 200.0, false, false);
            TextField tf = new TextField();
            tf.setText(z.getCaption());
            ImageView imageView = new ImageView(image);
            hbox.getChildren().addAll(imageView, new Label("Content"), tf);
            slideHbox.add(hbox);
            filenames.add(path);

        }

        addSlideBtn.setOnAction(e -> {

            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
            File selectedFile = fileChooser.showOpenDialog(window);
            if (selectedFile != null) {

                HBox hbox = new HBox();
                String filestart = "file://";
                System.out.print(selectedFile.getAbsolutePath());
                if (os.contains("Windows")) {
                    filestart = "file:///";
                }
                hbox.setOnMousePressed(f -> {
                    if (hbox != slideCurrent) {
                        slidePrevious = slideCurrent;
                        slideCurrent = hbox;

                        slideCurrent.setStyle("-fx-border-color:black;");
                        slideCurrent.setStyle("-fx-background-color:red;"
                                + "-fx-border-color: #000000;");
                        if (slidePrevious != null) {
                            slidePrevious.setStyle("-fx-border-color:white;");
                            slidePrevious.setStyle("-fx-background-color:white;"
                                    + "-fx-border-color: #000000;");
                        }

                    }

                });

                String path = filestart + selectedFile.getAbsolutePath();

                Image image = new Image(path, 200.0, 200.0, false, false);
                TextField tf = new TextField();
                ImageView imageView = new ImageView(image);
                hbox.getChildren().addAll(imageView, new Label("Content"), tf);
                slideHbox.add(hbox);
                fp.getChildren().clear();
                fp.getChildren().addAll(slideHbox);

                filenames.add(path);

            }

        });
        removeSlideBtn.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);
            if (!slideHbox.isEmpty()) {
                slideHbox.remove(index);
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);

        });

        upButton.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);
            if (index != 0) {
                int indexNext = slideHbox.indexOf(slideCurrent) - 1;

                HBox hboxOfcurrent = slideCurrent;
                HBox hboxOfnext = slideHbox.get(indexNext);

                if (slideHbox != null) {
                    slideHbox.set(indexNext, hboxOfcurrent);
                    slideHbox.set(index, hboxOfnext);
                }
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);
        });

        downButton.setOnAction(e -> {
            int index = slideHbox.indexOf(slideCurrent);

            if (index != (slideHbox.size() - 1)) {
                int indexNext = slideHbox.indexOf(slideCurrent) + 1;

                HBox hboxOfcurrent = slideCurrent;
                HBox hboxOfnext = slideHbox.get(indexNext);

                if (slideHbox != null) {
                    slideHbox.set(indexNext, hboxOfcurrent);
                    slideHbox.set(index, hboxOfnext);
                }
            }
            fp.getChildren().clear();
            fp.getChildren().addAll(slideHbox);
        });

        addToEproBtn.setOnAction(e -> {

            for (int i = 0; slideHbox.size() > i; i++) {

                for (int j = 0; slideHbox.get(i).getChildren().size() > j; j++) {

                    if (slideHbox.get(i).getChildren().get(j) instanceof TextField) {
                        TextField l = (TextField) slideHbox.get(i).getChildren().get(j);
                        comments.add(l.getText());

                        System.out.println(l.getText());
                    }

                }
                slides.add(new Slide(filenames.get(i), comments.get(i)));
            }

            publish = true;

            String[] strings = new String[0];
            SlideShow currentSlide = new SlideShow("SlideShow", titleField.getText(), slides);

            tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
            if (site == null) {
                site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

            }

            site.getContentList().set(indexg, currentSlide);
            site.getSSList().set(indexg, currentSlide);

            dialog.close();
            reloadPane(strings, site.getContentList(), "SlideShow", indexg);

        });
        cancelBtn.setOnAction(e -> {
            dialog.close();
        });

        toolBarLeft.getItems().addAll(addSlideBtn, removeSlideBtn, upButton, downButton);
        toolBarLeft.setOrientation(Orientation.VERTICAL);

        toolBarTop.getItems().addAll(addToEproBtn, cancelBtn, new Separator(), titleLabel, titleField);
        toolBarTop.setOrientation(Orientation.HORIZONTAL);

        BorderPane bp = new BorderPane();

        fp.getChildren().clear();

        fp.getChildren().addAll(slideHbox);

        sp.setContent(fp);

        bp.setLeft(toolBarLeft);
        bp.setTop(toolBarTop);

        bp.setCenter(sp);

        Scene dialogScene = new Scene(bp, 1000, 600);

        dialog.setScene(dialogScene);
        dialog.show();

    }

    public List<String> editaddList(List<String> sIn, int zook, String s) {

        List<String> strings = new ArrayList();
        List<String> listItems = new ArrayList(0);
        List<HBox> hboxess = new ArrayList();
        ScrollPane sp = new ScrollPane();
        FlowPane fp = new FlowPane();
        VBox vbox = new VBox();

        for (String z : sIn) {

            HBox hbox = new HBox(20);
            Integer counter = hboxess.size() + 1;
            hbox.getChildren().addAll(new Label(counter.toString() + "   "), new TextField(z));
            hbox.setPrefSize(400, 40);

            hboxess.add(hbox);

        }

        vbox.getChildren().clear();
        vbox.getChildren().addAll(hboxess);

        final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(window);

        ToolBar toolBarTop = new ToolBar();
        ToolBar toolBarLeft = new ToolBar();

        Button addListItemBtn = new Button("Add List Item");
        Button removeListItemBtn = new Button("Remove List Item");
        Button upButton = new Button("Up");
        Button downButton = new Button("Down");

        Button addToEproBtn = new Button("Add to Epro");
        Button cancelBtn = new Button("Cancel");
        ComboBox cb = new ComboBox();

        cb.getItems().addAll(
                "ol",
                "ul");

        cb.setValue(s);

// 
        boolean idk = false;

        addListItemBtn.setOnAction(e -> {

            HBox hbox = new HBox(20);
            Integer counter = hboxess.size() + 1;
            hbox.getChildren().addAll(new Label(counter.toString() + "   "), new TextField());
            hbox.setPrefSize(400, 40);

            hboxess.add(hbox);

            vbox.getChildren().clear();
            vbox.getChildren().addAll(hboxess);
            fp.getChildren().clear();
            fp.getChildren().add(vbox);

        });
        removeListItemBtn.setOnAction(e -> {
            if (hboxess.size() > 0) {
                hboxess.remove(hboxess.size() - 1);
            }
            vbox.getChildren().clear();
            vbox.getChildren().addAll(hboxess);
            fp.getChildren().clear();
            fp.getChildren().add(vbox);
        });

        addToEproBtn.setOnAction(e -> {
            for (int i = 0; hboxess.size() > i; i++) {

                for (int j = 0; hboxess.get(i).getChildren().size() > j; j++) {

                    if (hboxess.get(i).getChildren().get(j) instanceof TextField) {
                        TextField l = (TextField) hboxess.get(i).getChildren().get(j);
                        listItems.add(l.getText());

                    }

                }

            }

            String[] strings1 = new String[0];
            if (!listItems.isEmpty() || cb.getValue() != null) {
                eList newList = new eList("List", cb.getValue().toString(), listItems.size(), listItems);

                numoflists++;

                tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());
                if (site == null) {
                    site = (Site) tabPaneEdit.getTabs().get(tabPaneEdit.getSelectionModel().getSelectedIndex());

                }

                site.getContentList().set(zook, newList);
                if (!site.getLists().isEmpty()) {
                    site.getLists().set(zook, newList);
                } else {
                    site.getLists().add(newList);
                }
                dialog.close();
                reloadPane(strings1, site.getContentList(), "List", zook);
            }

        });
        cancelBtn.setOnAction(e -> {
            dialog.close();
        });

        toolBarLeft.getItems().addAll(addListItemBtn, removeListItemBtn);
        toolBarLeft.setOrientation(Orientation.VERTICAL);

        toolBarTop.getItems().addAll(addToEproBtn, cancelBtn, new Separator(), new Label("List Type: "), cb, new Separator());
        toolBarTop.setOrientation(Orientation.HORIZONTAL);

        BorderPane bp = new BorderPane();

        if (hboxess != null) {
            fp.getChildren().addAll(hboxess);
        }

        sp.setContent(fp);

        bp.setLeft(toolBarLeft);
        bp.setTop(toolBarTop);

        bp.setCenter(sp);

        Scene dialogScene = new Scene(bp, 700, 500);

        dialog.setScene(dialogScene);
        dialog.show();

        return strings;

    }

    public void reloadPane(String[] strings, List<Content> siteContent, String type, int index) {

        int counter = 0;
        ScrollPane sp = new ScrollPane();
        FlowPane fp = new FlowPane();
        boolean first = true;
        int f = siteContent.size();
        numofslideshows = site.getSSList().size();
        numoflists = site.getLists().size();

        for (int i = 0; i < siteContent.size(); i++) {

            if (null != type) {
                switch (type) {
                    case "Video": {
                        siteContent.size();
                        VBox vbox = new VBox();
                        Button removeButton = new Button("Remove");
                        removeButton.setVisible(false);

                        removeButton.setOnAction(e -> {

                            Alert alert = new Alert(AlertType.CONFIRMATION);
                            alert.setTitle("Confirmation Dialog");
                            alert.setHeaderText("Delete Content");
                            alert.setContentText("Do you want to delete this Content?");

                            Optional<ButtonType> result = alert.showAndWait();
                            if (result.get() == ButtonType.OK) {
                                // ... user chose OK

                                int r = site.getVboxList().indexOf(vbox);

                                site.getVboxList().remove(r);
                                site.getContentList().remove(r);
                                fp.getChildren().clear();
                                fp.getChildren().addAll(site.getVboxList());
                                sp.setContent(fp);
                                site.setContent(sp);

                            } else {
                                // ... user chose CANCEL or closed the dialog
                            }

                        });
                        Label filetype = new Label();
                        filetype.setText(" Type: " + "video");
                        filetype.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label filename = new Label();
                        filename.setText(" FileName: " + strings[1]);
                        filename.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label filepath = new Label();
                        filepath.setText(" FilePath: " + strings[0]);
                        Label height = new Label();
                        height.setText(" Height: " + strings[2]);
                        height.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label width = new Label();
                        width.setText(" Width: " + strings[3]);
                        width.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label caption = new Label();
                        caption.setText(" Caption: " + strings[4]);
                        caption.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        vbox.getChildren().addAll(filetype, filename, height, width, caption);
                        vbox.getChildren().add(removeButton);
                        if (first == true) {
                            if (index != -1) {
                                site.getVboxList().set(index, vbox);
                            } else {
                                site.getVboxList().add(vbox);
                            }
                        }

                        fp.getChildren().clear();
                        first = false;
                        vbox.setPrefSize(950, 100);
                        vbox.setStyle("-fx-border-color:GREY;");
                        vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                + "-fx-border-color: #000000;");
                        vbox.setOnMousePressed((MouseEvent e) -> {
                            if (vbox != current) {
                                previous = current;
                                current = vbox;
                                removeButton.setVisible(true);

                                current.setStyle("-fx-border-color:GREY;");
                                current.setStyle("-fx-background-color:white;"
                                        + "-fx-border-color: #000000;");
                                if (previous != null) {
                                    previous.setStyle("-fx-border-color:GREY;");
                                    previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                            + "-fx-border-color: #000000;");
                                    for (Node n : previous.getChildren()) {
                                        if (n instanceof Button) {
                                            Button r = (Button) n;
                                            r.setVisible(false);
                                        }
                                    }
                                }
                            }
                            if (e.getClickCount() == 2) {

                                String[] sNew = dialogVideoEdit(strings);
                                int g = site.getVboxList().indexOf(vbox);

                                Integer widthh = Integer.parseInt(sNew[2]);
                                Integer heighth = Integer.parseInt(sNew[3]);

                                site.getContentList().set(g, new Video("Video", sNew[0], sNew[1], heighth, widthh, sNew[4]));

                                reloadPane(sNew, site.getContentList(), "Video", g);
                            }

                        }
                        );
                        break;
                    }

                    case "Image": {
                        siteContent.size();
                        VBox vbox = new VBox();
                        Button removeButton = new Button("Remove");
                        removeButton.setVisible(false);

                        removeButton.setOnAction(e -> {

                            Alert alert = new Alert(AlertType.CONFIRMATION);
                            alert.setTitle("Confirmation Dialog");
                            alert.setHeaderText("Delete Content");
                            alert.setContentText("Do you want to delete this Content?");

                            Optional<ButtonType> result = alert.showAndWait();
                            if (result.get() == ButtonType.OK) {
                                // ... user chose OK

                                int r = site.getVboxList().indexOf(vbox);

                                site.getVboxList().remove(r);
                                site.getContentList().remove(r);
                                fp.getChildren().clear();
                                fp.getChildren().addAll(site.getVboxList());
                                sp.setContent(fp);
                                site.setContent(sp);
                            }

                        });
                        Label filetype = new Label();
                        filetype.setText(" Type: image");
                        filetype.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label filename = new Label();
                        filename.setText(" FileName: " + strings[1]);
                        filename.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label filepath = new Label();
                        filepath.setText(" FilePath: " + strings[0]);
                        Label height = new Label();
                        height.setText(" Height: " + strings[2]);
                        height.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label width = new Label();
                        width.setText(" Width: " + strings[3]);
                        width.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label caption = new Label();
                        caption.setText(" Caption: " + strings[4]);
                        caption.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label floatLocation = new Label();
                        floatLocation.setText(" Float Location: " + strings[5]);
                        floatLocation.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        vbox.getChildren().addAll(filetype, filename, height, width, caption, floatLocation);
                        vbox.getChildren().add(removeButton);
                        if (first == true) {
                            if (index != -1) {
                                site.getVboxList().set(index, vbox);
                            } else {
                                site.getVboxList().add(vbox);
                            }
                        }

                        fp.getChildren().clear();
                        first = false;
                        vbox.setPrefSize(950, 150);
                        vbox.setStyle("-fx-border-color:GREY;");
                        vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                + "-fx-border-color: #000000;");
                        vbox.setOnMousePressed(e -> {
                            if (vbox != current) {
                                previous = current;
                                current = vbox;
                                removeButton.setVisible(true);

                                current.setStyle("-fx-border-color:GREY;");
                                current.setStyle("-fx-background-color:white;"
                                        + "-fx-border-color: #000000;");
                                if (previous != null) {
                                    previous.setStyle("-fx-border-color:GREY;");
                                    previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                            + "-fx-border-color: #000000;");
                                    for (Node n : previous.getChildren()) {
                                        if (n instanceof Button) {
                                            Button r = (Button) n;
                                            r.setVisible(false);
                                        }
                                    }
                                }

                            }
                            if (e.getClickCount() == 2) {
                                String[] sNew = dialogAddImageEdit(strings);
                                int g = site.getVboxList().indexOf(vbox);

                                Integer widthh = Integer.parseInt(sNew[2]);
                                Integer heighth = Integer.parseInt(sNew[3]);

                                site.getContentList().set(g, new eImage("Image", sNew[0], sNew[1], heighth, widthh, sNew[4], sNew[5]));

                                reloadPane(sNew, site.getContentList(), "Image", g);

                            }

                        });
                        break;
                    }

                    case "List":
                        if (site.getLists() != null) {
                            VBox vbox = new VBox();
                            Button removeButton = new Button("Remove");
                            removeButton.setVisible(false);

                            removeButton.setOnAction(e -> {

                                Alert alert = new Alert(AlertType.CONFIRMATION);
                                alert.setTitle("Confirmation Dialog");
                                alert.setHeaderText("Delete Content");
                                alert.setContentText("Do you want to delete this Content?");

                                Optional<ButtonType> result = alert.showAndWait();
                                if (result.get() == ButtonType.OK) {
                                    // ... user chose OK

                                    int r = site.getVboxList().indexOf(vbox);

                                    site.getVboxList().remove(r);
                                    site.getContentList().remove(r);
                                    fp.getChildren().clear();
                                    fp.getChildren().addAll(site.getVboxList());
                                    sp.setContent(fp);
                                    site.setContent(sp);

                                } else {
                                    // ... user chose CANCEL or closed the dialog
                                }

                            });

//                List<Slide> slides = currentSlideShows.get(numofslideshows).getSlides();
                            Label l = new Label(" Type: List");
                            l.setStyle(" -fx-font-size: 12pt;\n"
                                    + "    -fx-font-family: \"Courier New\";\n"
                                    + "    -fx-base: rgb(132, 145, 47);\n"
                                    + "    -fx-background: rgb(225, 228, 203);");
                            vbox.getChildren().add(l);
                            //System.out.println(site.getSSList().get(numofslideshows).getSlides().size())
                            Label p = new Label(" Title: " + site.getLists().get(numoflists - 1).getListType());
                            p.setStyle(" -fx-font-size: 12pt;\n"
                                    + "    -fx-font-family: \"Courier New\";\n"
                                    + "    -fx-base: rgb(132, 145, 47);\n"
                                    + "    -fx-background: rgb(225, 228, 203);");
                            vbox.getChildren().add(p);

                            if ("ol".equals(site.getLists().get(numoflists - 1).getListType())) {
                                for (int k = 0; k < site.getLists().get(numoflists - 1).getListItems().size(); k++) {

                                    Label m = new Label(" ListItem: " + (k + 1) + ". " + site.getLists().get(numoflists - 1).getListItems().get(k));
                                    m.setStyle(" -fx-font-size: 12pt;\n"
                                            + "    -fx-font-family: \"Courier New\";\n"
                                            + "    -fx-base: rgb(132, 145, 47);\n"
                                            + "    -fx-background: rgb(225, 228, 203);");

                                    vbox.getChildren().addAll(m);

                                }
                            } else {
                                for (int k = 0; k < site.getLists().get(numoflists - 1).getListItems().size(); k++) {
                                    Label m = new Label(" ListItem: •" + site.getLists().get(numoflists - 1).getListItems().get(k));
                                    m.setStyle(" -fx-font-size: 12pt;\n"
                                            + "    -fx-font-family: \"Courier New\";\n"
                                            + "    -fx-base: rgb(132, 145, 47);\n"
                                            + "    -fx-background: rgb(225, 228, 203);");

                                    vbox.getChildren().addAll(m);
                                }
                            }
                            vbox.getChildren().add(removeButton);
                            if (first == true) {
                                if (index != -1) {
                                    site.getVboxList().set(index, vbox);
                                } else {
                                    site.getVboxList().add(vbox);
                                }
                            }

                            first = false;

                            vbox.setPrefSize(950, 100);
                            vbox.setStyle("-fx-border-color:GREY;");
                            vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                    + "-fx-border-color: #000000;");

                            vbox.setOnMousePressed(e -> {
                                if (vbox != current) {
                                    previous = current;
                                    current = vbox;
                                    removeButton.setVisible(true);

                                    current.setStyle("-fx-border-color:GREY;");
                                    current.setStyle("-fx-background-color:white;"
                                            + "-fx-border-color: #000000;");
                                    if (previous != null) {
                                        previous.setStyle("-fx-border-color:GREY;");
                                        previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                                + "-fx-border-color: #000000;");
                                        for (Node n : previous.getChildren()) {
                                            if (n instanceof Button) {
                                                Button r = (Button) n;
                                                r.setVisible(false);
                                            }
                                        }
                                    }

                                }
                                if (e.getClickCount() == 2) {

                                    String[] sNew = null;
                                    int g = site.getVboxList().indexOf(vbox);

                                    eList h = (eList) site.getContentList().get(g);

                                    editaddList(h.getListItems(), g, h.getListType());

                                    reloadPane(sNew, site.getContentList(), "List", g);

                                }

                            });

                        }
                        break;
                    case "Paragraph": {
                        siteContent.size();
                        VBox vbox = new VBox();
                        Button removeButton = new Button("Remove");
                        removeButton.setVisible(false);

                        removeButton.setOnAction(e -> {

                            Alert alert = new Alert(AlertType.CONFIRMATION);
                            alert.setTitle("Confirmation Dialog");
                            alert.setHeaderText("Delete Content");
                            alert.setContentText("Do you want to delete this Content?");

                            Optional<ButtonType> result = alert.showAndWait();
                            if (result.get() == ButtonType.OK) {
                                // ... user chose OK

                                int r = site.getVboxList().indexOf(vbox);

                                site.getVboxList().remove(r);
                                site.getContentList().remove(r);
                                fp.getChildren().clear();
                                fp.getChildren().addAll(site.getVboxList());
                                sp.setContent(fp);
                                site.setContent(sp);

                            } else {
                                // ... user chose CANCEL or closed the dialog
                            }

                        });
                        Label typeLabel = new Label(" Type: Paragraph");
                        typeLabel.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label sizeLabel = new Label(" Size: " + strings[0]);
                        sizeLabel.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        TextArea ta = new TextArea(strings[1]);
                        ta.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n");
                        ta.setEditable(false);
                        vbox.getChildren().addAll(typeLabel, sizeLabel, ta);
                        vbox.getChildren().add(removeButton);
                        if (first == true) {
                            if (index != -1) {
                                site.getVboxList().set(index, vbox);
                            } else {
                                site.getVboxList().add(vbox);
                            }
                        }

                        fp.getChildren().clear();
                        first = false;
                        vbox.setPrefSize(950, 200);
                        vbox.setStyle("-fx-border-color:GREY;");
                        vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                + "-fx-border-color: #000000;");
                        vbox.setOnMousePressed(e -> {
                            if (vbox != current) {
                                previous = current;
                                current = vbox;
                                removeButton.setVisible(true);

                                current.setStyle("-fx-border-color:GREY;");
                                current.setStyle("-fx-background-color:white;"
                                        + "-fx-border-color: #000000;");
                                if (previous != null) {
                                    previous.setStyle("-fx-border-color:GREY;");
                                    previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                            + "-fx-border-color: #000000;");
                                    for (Node n : previous.getChildren()) {
                                        if (n instanceof Button) {
                                            Button r = (Button) n;
                                            r.setVisible(false);
                                        }
                                    }
                                }

                            }
                            if (e.getClickCount() == 2) {

                                String[] sNew = dialogAddParagraphEdit(strings);
                                int g = site.getVboxList().indexOf(vbox);

                                site.getContentList().set(g, new Paragraph("Paragraph", sNew[0], sNew[1]));

                                reloadPane(sNew, site.getContentList(), "Paragraph", g);
                            }

                        });
                        break;
                    }
                    case "Header": {
                        siteContent.size();
                        VBox vbox = new VBox();
                        Button removeButton = new Button("Remove");
                        removeButton.setVisible(false);

                        removeButton.setOnAction(e -> {

                            Alert alert = new Alert(AlertType.CONFIRMATION);
                            alert.setTitle("Confirmation Dialog");
                            alert.setHeaderText("Delete Content");
                            alert.setContentText("Do you want to delete this Content?");

                            Optional<ButtonType> result = alert.showAndWait();
                            if (result.get() == ButtonType.OK) {
                                // ... user chose OK

                                int r = site.getVboxList().indexOf(vbox);

                                site.getVboxList().remove(r);
                                site.getContentList().remove(r);
                                fp.getChildren().clear();
                                fp.getChildren().addAll(site.getVboxList());
                                sp.setContent(fp);
                                site.setContent(sp);

                            } else {
                                // ... user chose CANCEL or closed the dialog
                            }

                        });
                        Label typeLabel = new Label(" Type: Header");
                        typeLabel.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label sizeLabel = new Label(" Size: " + strings[0]);
                        sizeLabel.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n"
                                + "    -fx-base: rgb(132, 145, 47);\n"
                                + "    -fx-background: rgb(225, 228, 203);");
                        Label ta = new Label(" Text: " + strings[1]);
                        ta.setStyle(" -fx-font-size: 12pt;\n"
                                + "    -fx-font-family: \"Courier New\";\n");
                        vbox.getChildren().addAll(typeLabel, sizeLabel, ta);
                        vbox.getChildren().add(removeButton);
                        if (first == true) {
                            if (index != -1) {
                                site.getVboxList().set(index, vbox);
                            } else {
                                site.getVboxList().add(vbox);
                            }
                        }
                        fp.getChildren().clear();
                        first = false;
                        vbox.setPrefSize(950, 100);
                        vbox.setStyle("-fx-border-color:GREY;");
                        vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                + "-fx-border-color: #000000;");
                        vbox.setOnMousePressed(e -> {
                            if (vbox != current) {
                                previous = current;
                                current = vbox;
                                removeButton.setVisible(true);

                                current.setStyle("-fx-border-color:GREY;");
                                current.setStyle("-fx-background-color:white;"
                                        + "-fx-border-color: #000000;");
                                if (previous != null) {
                                    previous.setStyle("-fx-border-color:GREY;");
                                    previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                            + "-fx-border-color: #000000;");
                                    for (Node n : previous.getChildren()) {
                                        if (n instanceof Button) {
                                            Button r = (Button) n;
                                            r.setVisible(false);

                                        }
                                    }
                                }

                            }
                            if (e.getClickCount() == 2) {
                                String[] sNew = dialogEditHeader(strings);
                                int g = site.getVboxList().indexOf(vbox);

                                site.getContentList().set(g, new Header("Header", sNew[0], sNew[1]));

                                reloadPane(sNew, site.getContentList(), "Header", g);

                            }

                        });
                        break;
                    }
                    case "SlideShow":
                        System.out.println(numofslideshows);
                        System.out.println(site.getSSList().size());

                        if (site.getSSList() != null) {
                            VBox vbox = new VBox();
                            Button removeButton = new Button("Remove");
                            removeButton.setVisible(false);

                            removeButton.setOnAction(e -> {

                                Alert alert = new Alert(AlertType.CONFIRMATION);
                                alert.setTitle("Confirmation Dialog");
                                alert.setHeaderText("Delete Content");
                                alert.setContentText("Do you want to delete this Content?");

                                Optional<ButtonType> result = alert.showAndWait();
                                if (result.get() == ButtonType.OK) {
                                    // ... user chose OK

                                    int r = site.getVboxList().indexOf(vbox);

                                    site.getVboxList().remove(r);
                                    site.getContentList().remove(r);

                                    fp.getChildren().clear();
                                    fp.getChildren().addAll(site.getVboxList());
                                    sp.setContent(fp);
                                    site.setContent(sp);

                                } else {
                                    // ... user chose CANCEL or closed the dialog
                                }

                            });

//                List<Slide> slides = currentSlideShows.get(numofslideshows).getSlides();
                            Label l = new Label(" Type: SlideShow");
                            l.setStyle(" -fx-font-size: 12pt;\n"
                                    + "    -fx-font-family: \"Courier New\";\n"
                                    + "    -fx-base: rgb(132, 145, 47);\n"
                                    + "    -fx-background: rgb(225, 228, 203);");
                            vbox.getChildren().add(l);
                            //System.out.println(site.getSSList().get(numofslideshows).getSlides().size());

                            Label p = new Label(" Title: " + site.getSSList().get(numofslideshows - 1).getTtile());
                            p.setStyle(" -fx-font-size: 12pt;\n"
                                    + "    -fx-font-family: \"Courier New\";\n"
                                    + "    -fx-base: rgb(132, 145, 47);\n"
                                    + "    -fx-background: rgb(225, 228, 203);");
                            vbox.getChildren().add(p);
                            for (int k = 0; k < site.getSSList().get(numofslideshows - 1).getSlides().size(); k++) {
                                Label m = new Label(" Path: " + site.getSSList().get(numofslideshows - 1).getSlides().get(k).getImagePath());
                                m.setStyle(" -fx-font-size: 12pt;\n"
                                        + "    -fx-font-family: \"Courier New\";\n"
                                        + "    -fx-base: rgb(132, 145, 47);\n"
                                        + "    -fx-background: rgb(225, 228, 203);");
                                Label u = new Label(" Caption: " + site.getSSList().get(numofslideshows - 1).getSlides().get(k).getCaption());
                                u.setStyle(" -fx-font-size: 12pt;\n"
                                        + "    -fx-font-family: \"Courier New\";\n"
                                        + "    -fx-base: rgb(132, 145, 47);\n"
                                        + "    -fx-background: rgb(225, 228, 203);");
                                vbox.getChildren().addAll(m, u);

                            }
                            vbox.getChildren().add(removeButton);
                            if (first == true) {
                                if (index != -1) {
                                    site.getVboxList().set(index, vbox);
                                } else {
                                    site.getVboxList().add(vbox);
                                }
                            }
                            fp.getChildren().clear();

                            first = false;

                            vbox.setPrefSize(950, 100);
                            vbox.setStyle("-fx-border-color:GREY;");
                            vbox.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                    + "-fx-border-color: #000000;");

                            vbox.setOnMousePressed(e -> {
                                if (vbox != current) {
                                    previous = current;
                                    current = vbox;
                                    removeButton.setVisible(true);
                                    current.setStyle("-fx-border-color:GREY;");
                                    current.setStyle("-fx-background-color:white;"
                                            + "-fx-border-color: #000000;");

                                    if (previous != null) {

                                        previous.setStyle("-fx-border-color:GREY;");
                                        previous.setStyle("-fx-background-color:linear-gradient( to left, #4895ec, azure );"
                                                + "-fx-border-color: #000000;");
                                        for (Node n : previous.getChildren()) {
                                            if (n instanceof Button) {
                                                Button r = (Button) n;
                                                r.setVisible(false);
                                            }
                                        }
                                    }

                                }
                                if (e.getClickCount() == 2) {

                                    String[] sNew = null;
                                    int g = site.getVboxList().indexOf(vbox);

                                    SlideShow h = (SlideShow) site.getContentList().get(g);

                                    h.getSlides();

                                    slideShowDialogEdit(g, h);

                                    reloadPane(sNew, site.getContentList(), "SlideShow", g);

                                }
                            });

                        }
                        break;
                }
            }
        }

        fp.getChildren().clear();
        fp.getChildren().addAll(site.getVboxList());
        sp.setContent(fp);
        site.setContent(sp);
    }

    public List eproLoad(String jsonFilePath) throws IOException {

        JsonObject jsonk = loadJSONFile(jsonFilePath);
        List<Site> sitesLoad = new ArrayList();
        List<VBox> vboes = new ArrayList();
        List<SlideShow> sss = new ArrayList();
        List<eList> lists = new ArrayList();
        List<Attributes> aLoad = new ArrayList();
        String SiteTitle = "";

        JsonArray jsonA = jsonk.getJsonArray("sites");

        for (int k = 0; k < jsonA.size(); k++) {

            aLoad.clear();
            JsonObject json = jsonA.getJsonObject(k);

            SiteTitle = json.getString("title");

            aLoad.add(new Name("Name", json.getString("name")));
            JsonObject json1 = json.getJsonObject("bannerImage");
            aLoad.add(new BannerImage("BannerImage", json1.getString("fileName"), json1.getString("path"), json1.getInt("height"), json1.getInt("width")));
            aLoad.add(new Footer("Footer", json.getString("footer")));
            aLoad.add(new Layout("Layout", json.getString("layout")));
            aLoad.add(new eFont("Font", json.getString("font")));
            aLoad.add(new Color("Color", json.getString("color")));
            List<Content> contentsLoad = new ArrayList();
            // NOW LOAD THE COURSE
            JsonArray jsonSlidesArray = json.getJsonArray("siteContent");
            for (int i = 0; i < jsonSlidesArray.size(); i++) {

                JsonObject slideJso = jsonSlidesArray.getJsonObject(i);
                int type = (Integer) slideJso.getInt("type");
                if (type == 1) {
                    JsonObject js = slideJso.getJsonObject("video");
                    System.out.println("Video");

                    contentsLoad.add(new Video("Video", js.getString("path"), js.getString("fileName"), js.getInt("height"), js.getInt("width"), js.getString("caption")));

                } else if (type == 2) {
                    JsonObject js = slideJso.getJsonObject("image");
                    contentsLoad.add(new eImage("Image", js.getString("path"), js.getString("fileName"), js.getInt("height"), js.getInt("width"), js.getString("caption"), js.getString("float")));

                } else if (type == 3) {
                    List<String> listitems = new ArrayList();
                    JsonObject js = slideJso.getJsonObject("list");
                    JsonArray jsArray = js.getJsonArray("listItems");
                    for (int j = 0; j < jsArray.size(); j++) {
                        listitems.add(jsArray.getString(j));

                    }
                    contentsLoad.add(new eList("List", js.getString("listTypes"), 0, listitems));
                } else if (type == 4) {
                    JsonObject js = slideJso.getJsonObject("paragraph");
                    contentsLoad.add(new Paragraph("Paragraph", js.getString("font"), js.getString("text")));

                } else if (type == 5) {
                    List<Slide> listitems = new ArrayList();
                    JsonObject js = slideJso.getJsonObject("slideShow");
                    JsonArray jsArray = js.getJsonArray("slides");
                    for (int j = 0; j < jsArray.size(); j++) {
                        JsonObject js1 = jsArray.getJsonObject(j);

                        listitems.add(new Slide((js1.getString("path") + js1.getString("filename")), js1.getString("caption")));

                    }
                    contentsLoad.add(new SlideShow("SlideShow", js.getString("title"), listitems));

                } else if (type == 6) {
                    JsonObject js = slideJso.getJsonObject("header");
                    contentsLoad.add(new Header("Header", js.getString("size"), js.getString("text")));

                }

            }

            //String inittitle, String initFilePath, int initkey, List<Content> intitcontent, List<VBox> initvboxes, List<SlideShow> initcurrentSlideShows, List<eList> initList,List <Attributes>initAttributes
            sitesLoad.add(new Site(SiteTitle, "null", sitesLoad.size(), contentsLoad, vboes, sss, lists, aLoad));
        }

        return sitesLoad;
    }

    public List eproLoadA(String jsonFilePath) throws IOException {
        JsonObject json = loadJSONFile(jsonFilePath);
        List<Attributes> aLoad = new ArrayList();
        String SiteTitle = json.getString("title");

        aLoad.add(new Name("Name", json.getString("name")));
        JsonObject json1 = json.getJsonObject("bannerImage");
        aLoad.add(new BannerImage("BannerImage", json1.getString("filename"), json1.getString("filePath"), json1.getInt("height"), json1.getInt("width")));
        aLoad.add(new Footer("Footer", json.getString("footer")));
        aLoad.add(new Layout("Layout", json.getString("layout")));
        aLoad.add(new eFont("Font", json.getString("font")));
        aLoad.add(new Color("Color", json.getString("color")));

        System.out.println(SiteTitle);

        for (Attributes a : aLoad) {
            System.out.println(a.getAttributeType());
        }

        return aLoad;
    }

    private JsonObject loadJSONFile(String jsonFilePath) throws IOException {
        InputStream is = new FileInputStream(jsonFilePath);
        JsonReader jsonReader = Json.createReader(is);
        JsonObject json = jsonReader.readObject();

        jsonReader.close();
        is.close();
        return json;
    }

    public void saveSlideShow(List<Site> slideShowToSave, String path, String fn) throws IOException {
        StringWriter sw = new StringWriter();

        JsonArrayBuilder jsb = Json.createArrayBuilder();

        for (int i = 0; i < slideShowToSave.size(); i++) {
            int j = 0;

            JsonArray slidesJsonArray = makeSlidesJsonArray(slideShowToSave.get(i).getContentList());
            Name n = (Name) slideShowToSave.get(i).getALists().get(j);

            j++;
            BannerImage bi = (BannerImage) slideShowToSave.get(i).getALists().get(j);
            j++;
            Footer f = (Footer) slideShowToSave.get(i).getALists().get(j);
            j++;
            Layout l = (Layout) slideShowToSave.get(i).getALists().get(j);
            j++;
            eFont font = (eFont) slideShowToSave.get(i).getALists().get(j);
            j++;
            Color c = (Color) slideShowToSave.get(i).getALists().get(j);

            JsonObject big = Json.createObjectBuilder()
                    .add("path", bi.getFilePath())
                    .add("fileName", bi.getFileName())
                    .add("height", bi.getHeight())
                    .add("width", bi.getWidth())
                    .build();

            // NOW BUILD THE COURSE USING EVERYTHING WE'VE ALREADY MADE
            JsonObject slideShowJsonObject = Json.createObjectBuilder()
                    .add("title", slideShowToSave.get(i).gettitle())
                    .add("name", n.getNameText())
                    .add("bannerImage", big)
                    .add("footer", f.getFooterText())
                    .add("font", font.getFontText())
                    .add("color", c.getFontText())
                    .add("layout", l.getLayoutText())
                    .add("siteContent", slidesJsonArray)
                    .build();

            jsb.add(slideShowJsonObject);
        }
        JsonObject slideShowJsonObject = Json.createObjectBuilder()
                .add("sites", jsb)
                .build();

        Map<String, Object> properties = new HashMap<>(1);
        properties.put(JsonGenerator.PRETTY_PRINTING, true);

        JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
        JsonWriter jsonWriter = writerFactory.createWriter(sw);
        jsonWriter.writeObject(slideShowJsonObject);

        jsonWriter.close();

        // INIT THE WRITER
        String jsonFilePath = path + ".json";
        OutputStream os = new FileOutputStream(jsonFilePath);
        JsonWriter jsonFileWriter = Json.createWriter(os);
        jsonFileWriter.writeObject(slideShowJsonObject);
        String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(jsonFilePath);
        pw.write(prettyPrinted);
        pw.close();
        System.out.println(prettyPrinted);

    }

    private JsonArray makeSlidesJsonArray(List<Content> slides) {
        JsonArrayBuilder jsb = Json.createArrayBuilder();
        for (Content slide : slides) {
            JsonObject jso = makeSlideJsonObject(slide);
            jsb.add(jso);
        }
        JsonArray jA = jsb.build();
        return jA;
    }

    private JsonObject makeSlideJsonObject(Content slide) {
        JsonObject j = null;
        if ("Video".equals(slide.getContentType())) {
            Video v = (Video) slide;
            JsonObject jso1 = Json.createObjectBuilder()
                    .add("path", v.getFilePath())
                    .add("fileName", v.getFileName())
                    .add("height", v.getHeight())
                    .add("width", v.getWidth())
                    .add("caption", v.getCaption())
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 1)
                    .add("video", jso1)
                    .build();
            j = jso;
        } else if ("Image".equals(slide.getContentType())) {
            eImage v = (eImage) slide;
            String caption = v.getCaption();
            String fl = v.getFloatLocation();
            System.out.println(caption + fl);

            JsonObject jso2 = Json.createObjectBuilder()
                    .add("path", v.getFilePath())
                    .add("fileName", v.getFileName())
                    .add("height", v.getHeight())
                    .add("width", v.getWidth())
                    .add("caption", caption)
                    .add("float", fl)
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 2)
                    .add("image", jso2)
                    .build();
            j = jso;
        } else if ("List".equals(slide.getContentType())) {
            eList v = (eList) slide;
            JsonArrayBuilder jsb = Json.createArrayBuilder();

            for (String s : v.getListItems()) {
                jsb.add(s);

            }
            JsonObject jso1 = Json.createObjectBuilder()
                    .add("listTypes", v.getListType())
                    .add("listItems", jsb)
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 3)
                    .add("list", jso1)
                    .build();
            j = jso;

        } else if ("Paragraph".equals(slide.getContentType())) {
            Paragraph v = (Paragraph) slide;
            JsonObject jso1 = Json.createObjectBuilder()
                    .add("font", v.getFont())
                    .add("text", v.getParagraph())
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 4)
                    .add("paragraph", jso1)
                    .build();
            j = jso;
        } else if ("SlideShow".equals(slide.getContentType())) {
            SlideShow v = (SlideShow) slide;
            JsonArrayBuilder jsb = Json.createArrayBuilder();

            v.getSlides().stream().map((s) -> Json.createObjectBuilder()
                    .add("filename", s.getImagePath())
                    .add("path", s.getCaption())
                    .build()).forEach((jso1) -> {
                        jsb.add(jso1);
                    });
            JsonObject jso1 = Json.createObjectBuilder()
                    .add("title", v.getTtile())
                    .add("slides", jsb)
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 5)
                    .add("slideShow", jso1)
                    .build();
            j = jso;

        } else if ("Header".equals(slide.getContentType())) {

            Header v = (Header) slide;
            JsonObject jso1 = Json.createObjectBuilder()
                    .add("size", v.getHeaderSize())
                    .add("text", v.getHeaderText())
                    .build();

            JsonObject jso = Json.createObjectBuilder()
                    .add("type", 6)
                    .add("header", jso1)
                    .build();
            j = jso;

        }

        return j;
    }

    private String makeSites(Site s) {

        s.setALists(Attributes);

        String la = "";
        String name = "";
        String color = "";
        String footer = "";
        String divSlides = "";
        String divCaptions = "";
        String font = "";
        List<String> siteTitles = new ArrayList();
        String returned = "";
        String divSites = "";
        String otherDivSites = "";
        String slash = "\\";
        String os = System.getProperty("os.name");
        BannerImage bi = null;
        String css = "";
        String cssFont = "";

        for (Attributes a : s.getALists()) {

            if (a instanceof Layout) {
                Layout l = (Layout) a;
                la = l.getLayoutText();
            } else if (a instanceof Name) {
                Name n = (Name) a;
                name = n.getNameText();

            } else if (a instanceof Color) {
                Color c = (Color) a;
                color = c.getFontText();

            } else if (a instanceof Footer) {
                Footer c = (Footer) a;
                footer = c.getFooterText();

            } else if (a instanceof eFont) {
                eFont c = (eFont) a;
                font = c.getFontText();

            } else if (a instanceof BannerImage) {
                bi = (BannerImage) a;
            }

        }

        if ("TimesRoman".equals(font)) {
            cssFont = "font-family: \"Times New Roman\", Times, serif;";
        } else if ("Verdana".equals(font)) {
            cssFont = "font-family: Verdana, Geneva, sans-serif;";
        } else if ("Arial".equals(font)) {
            cssFont = "font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;";
        } else if ("Courier".equals(font)) {
            cssFont = "font-family: 'Courier New', Courier, 'Lucida Sans Typewriter', 'Lucida Typewriter', monospace;";
        } else if ("Helvetica".equals(font)) {
            cssFont = "font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;";
        }

        System.out.println(cssFont);
        System.out.println(color);

        if ("Black/White".equals(color)) {
            if ("navLeft".equals(la)) {
                css = "div#vmenu {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em 0em .25em 0em;\n"
                        + "    border: solid 1px #FFFFFF;\n"
                        + "    background: black; \n"
                        + "    width: 13.5em;\n"
                        + "    position: fixed;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:link {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    background-color: #FFFFFF;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:active {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em .5em .25em .5em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #FFFFFF;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:visited {\n"
                        + "    margin: 0;\n"
                        + "    padding:  .25em .5em .25em .5em;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li a:hover {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background-color: #000000;\n"
                        + "    color: blue;\n"
                        + "\n"
                        + "}\n"
                        + "h1 {\n"
                        + "    background-color: #FFFFFF;\n"
                        + "    color: #000000 ;\n"
                        + "    font: bold 100px;\n"
                        + "    font-family: 'Suravaram', serif;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 80px;\n"
                        + "    height: 150px;\n"
                        + "    padding: 0px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}";
            } else {
                css = "h1 {\n"
                        + "    background-color: #333;\n"
                        + "    color: #FFFFFF ;\n"
                        + "    font: bold 80px;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 60px;\n"
                        + "    font-family: 'Droid Sans', sans-serif;\n"
                        + "    height: 100px;\n"
                        + "    padding: 25px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "p {\n"
                        + "    margin-top: 25px;\n"
                        + "    font-family: 'Raleway', sans-serif;\n"
                        + "}\n"
                        + "\n"
                        + ".nav-container {\n"
                        + "    background-color: #000000;\n"
                        + "}\n"
                        + ".nav {\n"
                        + "    height: 46px;\n"
                        + "    border-bottom: 4px solid #222;\n"
                        + "}\n"
                        + ".nav ul {\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + ".nav ul li {\n"
                        + "    line-height: 46px;\n"
                        + "    border-right: 2px solid #FFFFFF;\n"
                        + "    border-left: 2px solid #FFFFFF;\n"
                        + "}\n"
                        + ".nav ul li:first-child {\n"
                        + "    border-left: none;\n"
                        + "}\n"
                        + ".nav ul li:last-child {\n"
                        + "    border-right: none;\n"
                        + "}\n"
                        + ".nav ul li a {\n"
                        + "    text-decoration: none;\n"
                        + "    color: #FFFFFF;\n"
                        + "    font-size: 1.1em;\n"
                        + "    padding-left: 20px;\n"
                        + "    padding-right: 20px;\n"
                        + "    font-family: 'Oxygen', sans-serif;\n"
                        + "}\n"
                        + ".nav ul li a:hover {\n"
                        + "    background-color: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "    margin-left:auto; \n"
                        + "    margin-right:auto;\n"
                        + "}\n"
                        + ".content {\n"
                        + "    margin: 25px auto;\n"
                        + "}\n"
                        + "form    {\n"
                        + "    font-family: Tahoma, Geneva, sans-serif;\n"
                        + "    font-size: 14px;\n"
                        + "    font-style: italic;\n"
                        + "    line-height: 24px;\n"
                        + "    font-weight: bold;\n"
                        + "    color: black;\n"
                        + "    text-decoration: none;\n"
                        + "    border-radius: 10px;\n"
                        + "    padding:10px;\n"
                        + "    border: 1px solid #999;\n"
                        + "    box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Raleway', sans-serif;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Raleway', sans-serif;\n"
                        + "}";
            }

        } else if ("Red/Black".equals(color)) {
            if ("navLeft".equals(la)) {
                css = "div#vmenu {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em 0em .25em 0em;\n"
                        + "    border: solid 1px #1e831e;\n"
                        + "    background: red; \n"
                        + "    width: 13.5em;\n"
                        + "    position: fixed;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:link {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    background-color: red;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:active {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em .5em .25em .5em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: red;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:visited {\n"
                        + "    margin: 0;\n"
                        + "    padding:  .25em .5em .25em .5em;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #ffffff;\n"
                        + "    color: red;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li a:hover {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background-color: #000000;\n"
                        + "    color: red;\n"
                        + "\n"
                        + "}\n"
                        + "h1 {\n"
                        + "    background-color: red;\n"
                        + "    color: #000000 ;\n"
                        + "    font: bold 100px;\n"
                        + "    font-family: 'Suravaram', serif;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 80px;\n"
                        + "    height: 150px;\n"
                        + "    padding: 0px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}";
            } else {
                css = "h1 {\n"
                        + "    background-color: red;\n"
                        + "    color: #FFFFFF ;\n"
                        + "    font: bold 80px;\n"
                        + "    font-size: 60px;\n"
                        + "    font-family: 'Oswald', sans-serif;\n"
                        + "    height: 100px;\n"
                        + "    padding: 25px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "IMG.displayed {\n"
                        + "    height: 200px;\n"
                        + "    padding: 25px;\n"
                        + "}\n"
                        + ".nav-container {\n"
                        + "    background-color: #000000;\n"
                        + "}\n"
                        + ".nav {\n"
                        + "    height: 46px;\n"
                        + "    border-bottom: 4px solid #222;\n"
                        + "}\n"
                        + ".nav ul {\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + ".nav ul li {\n"
                        + "    line-height: 46px;\n"
                        + "    border-right: 2px solid #FFFFFF;\n"
                        + "    border-left: 2px solid #FFFFFF;\n"
                        + "\n"
                        + "}\n"
                        + "\n"
                        + ".nav ul li:first-child {\n"
                        + "    border-left: none;\n"
                        + "}\n"
                        + ".nav ul li:last-child {\n"
                        + "    border-right: none;\n"
                        + "}\n"
                        + ".nav ul li a {\n"
                        + "\n"
                        + "    display: block;\n"
                        + "    text-decoration: none;\n"
                        + "    color: #FFFFFF;\n"
                        + "    font-size: 1.1em;\n"
                        + "    padding-left: 20px;\n"
                        + "    padding-right: 20px;\n"
                        + "    font-family: 'Lora', serif;\n"
                        + "\n"
                        + "}\n"
                        + ".nav ul li a:hover {\n"
                        + "\n"
                        + "    background-color: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "}";
            }
        } else if ("Yellow".equals(color)) {
            if ("navLeft".equals(la)) {
                css = "div#vmenu {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em 0em .25em 0em;\n"
                        + "    border: solid 1px #1e831e;\n"
                        + "    background: yellow; \n"
                        + "    width: 13.5em;\n"
                        + "    position: fixed;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:link {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    background-color: yellow;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:active {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em .5em .25em .5em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: yellow;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:visited {\n"
                        + "    margin: 0;\n"
                        + "    padding:  .25em .5em .25em .5em;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #ffffff;\n"
                        + "    color: yellow;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li a:hover {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background-color: #000000;\n"
                        + "    color: yellow;\n"
                        + "\n"
                        + "}\n"
                        + "h1 {\n"
                        + "    background-color: yellow;\n"
                        + "    color: #000000 ;\n"
                        + "    font: bold 100px;\n"
                        + "    font-family: 'Suravaram', serif;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 80px;\n"
                        + "    height: 150px;\n"
                        + "    padding: 0px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}";
            } else {
                css = "h1 {\n"
                        + "    background-color: yellow;\n"
                        + "    color: #FFFFFF ;\n"
                        + "    font: bold 80px;\n"
                        + "    font-size: 60px;\n"
                        + "    font-family: 'Oswald', sans-serif;\n"
                        + "    height: 100px;\n"
                        + "    padding: 25px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "IMG.displayed {\n"
                        + "    height: 200px;\n"
                        + "    padding: 25px;\n"
                        + "}\n"
                        + ".nav-container {\n"
                        + "    background-color: #000000;\n"
                        + "}\n"
                        + ".nav {\n"
                        + "    height: 46px;\n"
                        + "    border-bottom: 4px solid #222;\n"
                        + "}\n"
                        + ".nav ul {\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + ".nav ul li {\n"
                        + "    line-height: 46px;\n"
                        + "    border-right: 2px solid #FFFFFF;\n"
                        + "    border-left: 2px solid #FFFFFF;\n"
                        + "\n"
                        + "}\n"
                        + "\n"
                        + ".nav ul li:first-child {\n"
                        + "    border-left: none;\n"
                        + "}\n"
                        + ".nav ul li:last-child {\n"
                        + "    border-right: none;\n"
                        + "}\n"
                        + ".nav ul li a {\n"
                        + "\n"
                        + "    display: block;\n"
                        + "    text-decoration: none;\n"
                        + "    color: #FFFFFF;\n"
                        + "    font-size: 1.1em;\n"
                        + "    padding-left: 20px;\n"
                        + "    padding-right: 20px;\n"
                        + "    font-family: 'Lora', serif;\n"
                        + "\n"
                        + "}\n"
                        + ".nav ul li a:hover {\n"
                        + "\n"
                        + "    background-color: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "}";
            }

        } else if ("Green".equals(color)) {
            if ("navLeft".equals(la)) {
                css = "div#vmenu {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em 0em .25em 0em;\n"
                        + "    border: solid 1px #1e831e;\n"
                        + "    background: green; \n"
                        + "    width: 13.5em;\n"
                        + "    position: fixed;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:link {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    background-color: green;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:active {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em .5em .25em .5em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: green;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:visited {\n"
                        + "    margin: 0;\n"
                        + "    padding:  .25em .5em .25em .5em;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #ffffff;\n"
                        + "    color: green;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li a:hover {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background-color: #000000;\n"
                        + "    color: green;\n"
                        + "\n"
                        + "}\n"
                        + "h1 {\n"
                        + "    background-color: green;\n"
                        + "    color: #000000 ;\n"
                        + "    font: bold 100px;\n"
                        + "    font-family: 'Suravaram', serif;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 80px;\n"
                        + "    height: 150px;\n"
                        + "    padding: 0px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}";
            } else {
                css = "h1 {\n"
                        + "    background-color: green;\n"
                        + "    color: #FFFFFF ;\n"
                        + "    font: bold 80px;\n"
                        + "    font-size: 60px;\n"
                        + "    font-family: 'Oswald', sans-serif;\n"
                        + "    height: 100px;\n"
                        + "    padding: 25px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "IMG.displayed {\n"
                        + "    height: 200px;\n"
                        + "    padding: 25px;\n"
                        + "}\n"
                        + ".nav-container {\n"
                        + "    background-color: #000000;\n"
                        + "}\n"
                        + ".nav {\n"
                        + "    height: 46px;\n"
                        + "    border-bottom: 4px solid #222;\n"
                        + "}\n"
                        + ".nav ul {\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + ".nav ul li {\n"
                        + "    line-height: 46px;\n"
                        + "    border-right: 2px solid #FFFFFF;\n"
                        + "    border-left: 2px solid #FFFFFF;\n"
                        + "\n"
                        + "}\n"
                        + "\n"
                        + ".nav ul li:first-child {\n"
                        + "    border-left: none;\n"
                        + "}\n"
                        + ".nav ul li:last-child {\n"
                        + "    border-right: none;\n"
                        + "}\n"
                        + ".nav ul li a {\n"
                        + "\n"
                        + "    display: block;\n"
                        + "    text-decoration: none;\n"
                        + "    color: #FFFFFF;\n"
                        + "    font-size: 1.1em;\n"
                        + "    padding-left: 20px;\n"
                        + "    padding-right: 20px;\n"
                        + "    font-family: 'Lora', serif;\n"
                        + "\n"
                        + "}\n"
                        + ".nav ul li a:hover {\n"
                        + "\n"
                        + "    background-color: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "}";
            }

        } else if ("Blue".equals(color)) {
            if ("navLeft".equals(la)) {
                css = "div#vmenu {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em 0em .25em 0em;\n"
                        + "    border: solid 1px #1e831e;\n"
                        + "    background: blue; \n"
                        + "    width: 13.5em;\n"
                        + "    position: fixed;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li {\n"
                        + "    margin: 0;\n"
                        + "    padding: 0;\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:link {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    background-color: blue;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:active {\n"
                        + "    margin: 0;\n"
                        + "    padding: .25em .5em .25em .5em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: blue;\n"
                        + "    color: #000000;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul a:visited {\n"
                        + "    margin: 0;\n"
                        + "    padding:  .25em .5em .25em .5em;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    text-decoration: none;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background: #ffffff;\n"
                        + "    color: blue;\n"
                        + "}\n"
                        + "\n"
                        + "div#vmenu ul li a:hover {\n"
                        + "    margin: 0;\n"
                        + "    padding: .2em 0em .2em .4em;\n"
                        + "    text-decoration: none;\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "    font-weight: bold;\n"
                        + "    font-size: medium;\n"
                        + "    background-color: #000000;\n"
                        + "    color: blue;\n"
                        + "\n"
                        + "}\n"
                        + "h1 {\n"
                        + "    background-color: blue;\n"
                        + "    color: #000000 ;\n"
                        + "    font: bold 100px;\n"
                        + "    font-family: 'Suravaram', serif;\n"
                        + "    font-style: italic;\n"
                        + "    font-size: 80px;\n"
                        + "    height: 150px;\n"
                        + "    padding: 0px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "h2{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}\n"
                        + "h4{\n"
                        + "    font-family: 'Hind Siliguri', sans-serif;\n"
                        + "}";
            } else {
                css = "h1 {\n"
                        + "    background-color: #2e2ece;\n"
                        + "    color: #FFFFFF ;\n"
                        + "    font: bold 80px;\n"
                        + "    font-size: 60px;\n"
                        + "    font-family: 'Oswald', sans-serif;\n"
                        + "    height: 100px;\n"
                        + "    padding: 25px;\n"
                        + "    text-shadow: 0 1px 1px #4d4d4d;\n"
                        + "}\n"
                        + "IMG.displayed {\n"
                        + "    height: 200px;\n"
                        + "    padding: 25px;\n"
                        + "}\n"
                        + ".nav-container {\n"
                        + "    background-color: #000000;\n"
                        + "}\n"
                        + ".nav {\n"
                        + "    height: 46px;\n"
                        + "    border-bottom: 4px solid #222;\n"
                        + "}\n"
                        + ".nav ul {\n"
                        + "    list-style: none;\n"
                        + "}\n"
                        + ".nav ul li {\n"
                        + "    line-height: 46px;\n"
                        + "    border-right: 2px solid #FFFFFF;\n"
                        + "    border-left: 2px solid #FFFFFF;\n"
                        + "\n"
                        + "}\n"
                        + "\n"
                        + ".nav ul li:first-child {\n"
                        + "    border-left: none;\n"
                        + "}\n"
                        + ".nav ul li:last-child {\n"
                        + "    border-right: none;\n"
                        + "}\n"
                        + ".nav ul li a {\n"
                        + "\n"
                        + "    display: block;\n"
                        + "    text-decoration: none;\n"
                        + "    color: #FFFFFF;\n"
                        + "    font-size: 1.1em;\n"
                        + "    padding-left: 20px;\n"
                        + "    padding-right: 20px;\n"
                        + "    font-family: 'Lora', serif;\n"
                        + "\n"
                        + "}\n"
                        + ".nav ul li a:hover {\n"
                        + "\n"
                        + "    background-color: #ffffff;\n"
                        + "    color: #000000;\n"
                        + "}";
            }

        }

        String strManyDirectories = name + "/sites/" + s.gettitle() + "/css";
        String strManyDirectories1 = name + "/sites/" + s.gettitle() + "/js";
        String strManyDirectories3 = name + "/sites/" + s.gettitle() + "/img";
        String strDirectoy = "test";
        String curDir = System.getProperty("user.dir");
        System.out.println(curDir);

        if (os.contains("Windows")) {

            String replaced = curDir.replace("\\", "/");
            curDir = replaced;

        }

        try {

            // Create multiple directories
            boolean success = (new File(strManyDirectories)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories + " created");
            }
            success = (new File(strManyDirectories1)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories1 + " created");
            }
            success = (new File(strManyDirectories3)).mkdirs();
            if (success) {
                System.out.println("Directories: " + strManyDirectories3 + " created");
            }

        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }

        for (Site k : sites) {

            divSites += "                    <li>\n"
                    + "                        <a href=\"" + k.gettitle() + ".html\">\n"
                    + k.gettitle()
                    + "                        </a>\n"
                    + "                    </li>\n";
        }

        if ("navTopLeft".equals(la)) {
            returned += "<!DOCTYPE html>\n"
                    + "<!--\n"
                    + "To change this license header, choose License Headers in Project Properties.\n"
                    + "To change this template file, choose Tools | Templates\n"
                    + "and open the template in the editor.\n"
                    + "-->\n"
                    + "\n"
                    + "<html>\n"
                    + "    <head>\n"
                    + "        <title>\n"
                    + s.gettitle()
                    + "        </title>\n"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "<link rel=\"stylesheet\" href=\"" + s.gettitle() + "/css/" + s.gettitle() + ".css" + "\" type=\"text/css\" media=\"screen\">"
                    + "        <LINK rel=\"stylesheet\" type=\"text/css\" href=\"../../css/navTopLayout.css\" title=\"Default Styles\" media=\"screen\">\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Raleway:500' rel='stylesheet' type='text/css'>\n"
                    + "        <script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/new.js\"></script>\n"
                    + "        <script src=\"js/navBar.js\"></script>\n"
                    + "<script src=\"" + s.gettitle() + "/js/" + s.gettitle() + ".js\"></script>"
                    + "\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "        <div class=\"nav-container\">\n"
                    + "            <div class=\"nav\">\n"
                    + "                <ul>\n"
                    + divSites
                    + "                </ul>\n"
                    + "\n"
                    + "            </div>\n"
                    + "        </div>"
                    + "<h1>" + name + "</h1>";
        } else if ("navMiddle".equals(la)) {

            returned += "<!DOCTYPE html>\n"
                    + "<html>\n"
                    + "    <head>\n"
                    + "\n"
                    + "        <title>" + s.gettitle() + "</title>\n"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "\n"
                    + "<link rel=\"stylesheet\" href=\"" + s.gettitle() + "/css/" + s.gettitle() + ".css" + "\" type=\"text/css\" media=\"screen\">"
                    + "        <LINK rel=\"stylesheet\" type=\"text/css\" href=\"../../css/navMiddleLayout.css\" title=\"Default Styles\" media=\"screen\">\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Lora' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>\n"
                    + "        <script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/new.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/navBar.js\" type=\"text/javascript\"></script>\n"
                    + "<script src=\"" + s.gettitle() + "/js/" + s.gettitle() + ".js\"></script>"
                    + "\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "        <h1>" + name + "</h1>\n"
                    + "        <div class=\"nav-container\">\n"
                    + "            <div class=\"nav\">\n"
                    + "                <ul>\n" + divSites
                    + "                </ul>\n"
                    + "\n"
                    + "            </div>\n"
                    + "        </div>";
        } else if ("navLeft".equals(la)) {
            returned += "<!DOCTYPE html>\n"
                    + "<html>\n"
                    + "    <head>\n"
                    + "<link rel=\"stylesheet\" href=\"" + s.gettitle() + "/css/" + s.gettitle() + ".css" + "\" type=\"text/css\" media=\"screen\">"
                    + "        <LINK rel=\"stylesheet\" type=\"text/css\" href=\"../../css/navLeftLayout.css\" title=\"Default Styles\" media=\"screen\">\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Hind+Siliguri' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Suravaram' rel='stylesheet' type='text/css'>\n"
                    + "        <script src=\"js/new.js\"></script>\n"
                    + "<script src=\"" + s.gettitle() + "/js/" + s.gettitle() + ".js\"></script>"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "        <meta name=\"description\" content=\"Nick Genco\">\n"
                    + "        <meta name=\"keywords\" content=\"NickGenco, Software, Developer\">\n"
                    + "        <meta name=\"author\" content=\"Nick Genco\">\n"
                    + "        <title>\n" + s.gettitle()
                    + "        </title>\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "<h1>" + name + "</h1>"
                    + "        <div id=\"vmenu\">\n"
                    + "            <ul>\n" + divSites
                    + "            </ul>  \n"
                    + "        </div> ";

        } else if ("navMiddleLeft".equals(la)) {
            returned += "<html>\n"
                    + "    <head>\n"
                    + "        <title>\n" + s.gettitle()
                    + "        </title>\n"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "        <meta name=\"description\" content=\"Nick Genco\">\n"
                    + "        <meta name=\"keywords\" content=\"NickGenco, Software, Developer\">\n"
                    + "        <meta name=\"author\" content=\"Nick Genco\">\n"
                    + "<link rel=\"stylesheet\" href=\"" + s.gettitle() + "/css/" + s.gettitle() + ".css" + "\" type=\"text/css\" media=\"screen\">"
                    + "        <LINK rel=\"stylesheet\" type=\"text/css\" href=\"../../css/navTopLayout.css\" title=\"Default Styles\" media=\"screen\">\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>\n"
                    + "        <script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/new.js\"></script>\n"
                    + "        <script src=\"js/navBar.js\"></script>\n"
                    + "<script src=\"" + s.gettitle() + "/js/" + s.gettitle() + ".js\"></script>"
                    + "\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "        <div class=\"video\">\n"
                    + "            <img src=\"" + bi.getFileName() + "\" width=\"" + bi.getWidth() + "\" height=\"" + bi.getHeight() + "\" alt=\"Sig\">\n"
                    + "        </div>\n"
                    + "        <div class=\"nav-container\">\n"
                    + "            <div class=\"nav\">\n"
                    + "                <ul>\n" + divSites
                    + "                </ul>\n"
                    + "\n"
                    + "            </div>\n"
                    + "        </div>";
        } else if ("navTopMiddle".equals(la)) {
            returned += "<!DOCTYPE html>\n"
                    + "<html>\n"
                    + "    <head>\n"
                    + "\n" + "        <title>\n" + s.gettitle()
                    + "        </title>\n"
                    + "\n"
                    + "<link rel=\"stylesheet\" href=\"" + s.gettitle() + "/css/" + s.gettitle() + ".css" + "\" type=\"text/css\" media=\"screen\">"
                    + "        <LINK rel=\"stylesheet\" type=\"text/css\" href=\"../../css/navMiddleLayout.css\" title=\"Default Styles\" media=\"screen\">\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Source+Code+Pro' rel='stylesheet' type='text/css'>\n"
                    + "        <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>\n"
                    + "        <script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/new.js\" type=\"text/javascript\"></script>\n"
                    + "        <script src=\"js/navBar.js\" type=\"text/javascript\"></script>\n"
                    + "<script src=\"" + s.gettitle() + "/js/" + s.gettitle() + ".js\"></script>"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "\n"
                    + "\n"
                    + "        <div class=\"nav-container\">\n"
                    + "            <div class=\"nav\">\n"
                    + "                <ul>\n"
                    + divSites
                    + "                </ul>\n"
                    + "\n"
                    + "            </div>\n"
                    + "        </div>\n"
                    + "        <h1>Nicholas Genco</h1>";
        }

        for (Content c : s.getContentList()) {
            if (c instanceof eImage) {
                eImage img = (eImage) c;
                returned += "<img src=\"" + img.getFileName() + "\" alt=" + "\"dontcare\" " + "\"height=\"" + img.getHeight() + " \"width=\"" + img.getWidth() + "\">";
                returned += "<p>" + img.getCaption() + "</p>";

            } else if (c instanceof Video) {
                Video v = (Video) c;
                returned += "  <div class=\"video\">\n"
                        + "            <center><video width=\"" + v.getWidth() + " \"height=\"" + v.getWidth() + "\" controls>\n"
                        + "                <source src=\"" + v.getFilePath() + "\" type=\"video/mp4\">\n"
                        + "\n"
                        + "                Your browser does not support the video tag.\n"
                        + "            </video><p>" + v.getCaption() + "</p></center>\n"
                        + "        </div>";

            } else if (c instanceof Paragraph) {

                Paragraph p = (Paragraph) c;
                returned += "<p>" + p.getParagraph() + "</p>";

            } else if (c instanceof Header) {

                Header p = (Header) c;
                returned += "<" + p.getHeaderSize() + ">" + p.getHeaderText() + "</" + p.getHeaderSize() + ">";

            } else if (c instanceof SlideShow) {
                SlideShow slideShow = (SlideShow) c;
                for (int i = 0; i < slideShow.getSlides().size(); i++) {
                    System.out.println("Nick" + i);
                    Slide newSlide = slideShow.getSlides().get(i);
                    String path = newSlide.getImagePath();
                    divSlides += "imgsrc[" + i + "]=\"" + path + "\";\n";

                    if (i == slideShow.getSlides().size() - 1) {
                        divCaptions += "\"" + newSlide.getCaption() + "\"";
                    } else {
                        divCaptions += "\"" + newSlide.getCaption() + "\",";
                    }
                }

                returned += "<h2>" + slideShow.getTtile() + "</h2><center><img id=\"slideshow\" src=\"" + slideShow.getSlides().get(0).getImagePath() + "\" height=\"400\" width=\"400\"/></center>\n"
                        + "<center><p id=\"demo\"></p></center>\n"
                        + "\n"
                        + "<br />\n"
                        + " <br />\n"
                        + " <center>           <input id=\"previous\" alt = \"previous\" type=\"image\" src=\"../../imgs/Previous.png\" width=\"20\" height=\"18\" onclick=\"mode('previous');\n"
                        + "                    startSlideshow();\"/>&nbsp;&nbsp;&nbsp;&nbsp;\n"
                        + "            <input id=\"play\" alt = \"play\" type=\"image\" src=\"../../imgs/play.png\" width=\"20\" height=\"18\" onclick=\"mode('play');\n"
                        + "                    startSlideshow();\" />\n"
                        + "            <input id=\"pause\" alt = \"pause\"  type=\"image\" src=\"../../imgs/pause.png\" width=\"20\" height=\"18\"  hidden=\"hidden\" onclick=\"mode('pause');\n"
                        + "                    startSlideshow();\" />&nbsp;&nbsp;&nbsp;&nbsp;\n"
                        + "            <input id=\"next\" alt = \"next\" type=\"image\" src=\"../../imgs/Next.png\" width=\"20\" height=\"18\" onclick=\"mode('next');\n"
                        + "                    startSlideshow();\" /></center>\n"
                        + "        </div>\n"
                        + "        <br />"
                        + "</center>";

                FileWriter fWriterJS = null;
                BufferedWriter writerJS = null;

                try {
                    //String filename = strManyDirectories2 + "/fileName.html";

                    fWriterJS = new FileWriter(strManyDirectories1 + "/" + s.gettitle() + ".js");
                    writerJS = new BufferedWriter(fWriterJS);
                    System.out.println("hello");
                    writerJS.write("var i = 0, imgsrc = new Array(), preload = new Array();\n"
                            + divSlides + "var person = [" + divCaptions + "];\n"
                            + "\n"
                            + "\n"
                            + "for (var j=0;j<imgsrc.length;j++)\n"
                            + "{\n"
                            + "preload[j] = new Image;\n"
                            + "preload[j].src = imgsrc[j];\n"
                            + "}\n"
                            + "function mode(param)\n"
                            + "{\n"
                            + "smode=param;\n"
                            + "}\n"
                            + "\n"
                            + "\n"
                            + "function startSlideshow()\n"
                            + "{\n"
                            + "if(smode==\"play\")\n"
                            + "{\n"
                            + "document.getElementById(\"play\").hidden=\"hidden\";\n"
                            + "document.getElementById(\"pause\").hidden=\"\";\n"
                            + "document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "document.getElementById(\"demo\").innerHTML = person[i];\n" + "document.getElementById(\"previous\").hidden=\"hidden\";\n"
                            + "document.getElementById(\"next\").hidden=\"hidden\";"
                            + "i++;\n"
                            + "setTimeout(\"startSlideshow()\",3000);\n"
                            + "}\n"
                            + "else if(smode==\"pause\")\n"
                            + "{\n"
                            + "document.getElementById(\"pause\").hidden=\"hidden\";\n"
                            + "document.getElementById(\"play\").hidden=\"\";\n"
                            + "document.getElementById(\"play\").value=\"Resume\";\n" + "document.getElementById(\"previous\").hidden=\"\";\n"
                            + "document.getElementById(\"next\").hidden=\"\";"
                            + "}\n"
                            + "else if(smode==\"stop\")\n"
                            + "{\n"
                            + "document.getElementById(\"play\").disabled=\"\";\n"
                            + "document.getElementById(\"play\").value=\"Play\";\n"
                            + "document.getElementById(\"pause\").disabled=\"disabled\";\n"
                            + "document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "document.getElementById(\"demo\").innerHTML = person[i];\n"
                            + "i=0;\n"
                            + "}\n"
                            + "else if(smode==\"next\")\n"
                            + "	\n"
                            + "{   \n"
                            + "\n"
                            + "	\n"
                            + "	if(i<(imgsrc.length-1))\n"
                            + "	{\n"
                            + "		i++;\n"
                            + "   		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                            + "    }\n"
                            + "	else\n"
                            + "	{\n"
                            + "		i=0;\n"
                            + "		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                            + "	}\n"
                            + "	\n"
                            + "	\n"
                            + "	\n"
                            + "	\n"
                            + "}\n"
                            + "else if(smode==\"previous\")\n"
                            + "{\n"
                            + "	\n"
                            + "	\n"
                            + "	if(i>0)\n"
                            + "	{\n"
                            + "		i--;\n"
                            + "   		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                            + "    }\n"
                            + "	else\n"
                            + "	{\n"
                            + "		i=imgsrc.length-1;\n"
                            + "		document.getElementById(\"slideshow\").src=imgsrc[i];\n"
                            + "		document.getElementById(\"demo\").innerHTML = person[i];\n"
                            + "	}\n"
                            + "\n"
                            + "\n"
                            + "   \n"
                            + "}\n"
                            + "if(i==imgsrc.length)\n"
                            + "{\n"
                            + "i=0;\n"
                            + "}\n"
                            + "}");
                    writerJS.newLine(); //this is not actually needed for html files - can make your code more readable though 
                    writerJS.close(); //make sure you close the writer object 

                } catch (Exception e) {
                    //catch any exceptions here
                    System.out.println("hellaascascasco");
                }

            } else if (c instanceof eList) {
                eList lsit = (eList) c;

                returned += "<" + lsit.getListType() + ">";

                for (String string : lsit.getListItems()) {
                    returned += "<li>" + string + "</li>";

                }

                returned += "<" + lsit.getListType() + "/>";
            }

        }
        FileWriter fWriterCSS = null;
        BufferedWriter writerCSS = null;

        try {
            //String filename = strManyDirectories2 + "/fileName.html";

            fWriterCSS = new FileWriter(strManyDirectories + "/" + s.gettitle() + ".css");
            writerCSS = new BufferedWriter(fWriterCSS);
            System.out.println(".css printed ");
            writerCSS.write(css);
            writerCSS.newLine(); //this is not actually needed for html files - can make your code more readable though 
            writerCSS.close(); //make sure you close the writer object 

        } catch (Exception e) {
            //catch any exceptions here
            System.out.println("hellaascascasco");
        }

        returned += "<h3>" + footer + "</body></html>";

        return returned;
    }

}
