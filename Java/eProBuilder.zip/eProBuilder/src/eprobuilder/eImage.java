/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eprobuilder;

/**
 *
 * @author nicholasgenco
 */
public class eImage extends Content {
    
    String filePath;
    String fileName;
    int Height;
    int Width;
    String caption;
    String floatLocation;
    
    
     public eImage(String initType, String intitfileName, String initFilePath, int initHeight, int intWidth, String itintcaption, String intitfloat){
        super(initType);
        fileName = intitfileName;
        filePath= initFilePath;
        Height= initHeight;
        Width= intWidth;
        caption = itintcaption;
        floatLocation = intitfloat;
      
        
     }
    public void setWidth(int initWidth){
        Width= initWidth;
    }
    public void setHeight(int initHeight){
        Height= initHeight;
    }
    public void setFilePath(String initFilePath){
        filePath= initFilePath;
    }
     public void setFileName(String initFileName){
        fileName= initFileName;
    }
      public int getWidth(){
        return Width;
    }
    public int getHeight(){
         return Height;
    }
    public String getFilePath(){
        return filePath;
    }
    public String getFileName(){
        return fileName;
    }
    public void setCaption(String initCaption){
        caption= initCaption;
    }
    public void setFloatLocation(String initlocation){
        floatLocation= initlocation;
    }
     public String getCaption(){
        return caption;
    }
    public String getFloatLocation(){
        return floatLocation;
    }
}
